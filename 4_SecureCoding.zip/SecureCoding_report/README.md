# SecureCoding_report

### _Reference Link_
* [실습 환경 구성 setup 파일(MOSAIC)](http://mosaic.sec.samsung.net/kms/comty.do?comtyId=492964550&menuId=561721126&postId=582748901&page=view&type=LIST)
* [실습 script](script.txt)
* [MOOC 영상(SW Expert Academy)](https://swexpertacademy.samsung.com/common/main/main.do) <br>
[Clean Code](https://swexpertacademy.samsung.com/common/academics/moocView.do?viewType=mooc&menuId=F2030&ocwKind=W2301&provider=&ocwSeq=797&detGbn=list&act=v&classifyCd2=W3150&classifyNm=S%2FW+Engineering+%3E+Code+Review&curPage=1&searchOrder=view_cnt&firstChangeLang=&lastCheckId=W5611&lastCheckMidId=&midMenuId=null&largeMenuId=&listType=thumbnail&categoryType=&searchGbn=tag&searchStr=&pageIndex=1)
, [Secure Coding](https://swexpertacademy.samsung.com/common/academics/moocView.do?viewType=mooc&menuId=F2030&ocwKind=W2301&provider=&ocwSeq=797&detGbn=list&act=v&classifyCd2=W3150&classifyNm=S%2FW+Engineering+%3E+Code+Review&curPage=1&searchOrder=view_cnt&firstChangeLang=&lastCheckId=W5611&lastCheckMidId=&midMenuId=null&largeMenuId=&listType=thumbnail&categoryType=&searchGbn=tag&searchStr=&pageIndex=1)
* [MOOC 강의 자료(MOSAIC)](http://mosaic.sec.samsung.net/kms/comty.do?comtyId=492964550&menuId=561721126&postId=846443723&page=view&type=LIST)
* [과목 소개(MOSAIC)](http://mosaic.sec.samsung.net/kms/comty.do?comtyId=492964550&menuId=561721126&postId=867746117&page=view&type=LIST)
* [과제(Option)](problem.md)
* [제출방법](submit.md)
* [FAQ](FAQ.md)
<br>

--------
### _시간표_
![시간표](result_img/timetable.PNG)
<br>

--------
### _Report Link_
|번호|이름|
|:---:|:----:|
|예제|[홍길동](홍길동.md)|
|1|[김주훈](김주훈.md)|
|2|[김성훈](김성훈.md)|
|3|[하인수](하인수.md)|
|4|[염우식](염우식.md)|
|5|[강민석](강민석.md)|
|6|[정래건](정래건.md)|
|7|[김윤래](김윤래.md)|
|8|[윤정현](윤정현.md)|
|9|[장영배](장영배.md)|
|10|[송현근](송현근.md)|
|11|[이근순](이근순.md)|
|12|[송주석](송주석.md)|
|13|[송도엽](송도엽.md)|
|14|[박세형](박세형.md)|
|15|[박윤균](박윤균.md)|
|16|[박승호](박승호.md)|
|17|[박정현](박정현.md)|
|18|[송예슬](송예슬.md)|
|19|[황진영](황진영.md)|
|20|[권정훈](권정훈.md)|
|21|[오연석](오연석.md)|
|22|[최성자](최성자.md)|
|23|[박정호](박정호.md)|
|24|[김현지](김현지.md)|
|25|[이상욱](이상욱.md)|
|26|[장경미](장경미.md)|
|27|[정재훈](정재훈.md)|
|28|[이철준](이철준.md)|
|29|[최성원](최성원.md)|
|30|[김경은](김경은.md)|
|31|[양재모](양재모.md)|
|32|[임용태](임용태.md)|
|33|[송종헌](송종헌.md)|
|34|[김남현](김남현.md)|
|35|[정재원](정재원.md)|
|36|[안종현](안종현.md)|
|37|[황서영](황서영.md)|
|38|[문소성](문소성.md)|
|39|[김정인](김정인.md)|
|40|[윤장호](윤장호.md)|
|41|[박선주](박선주.md)|
|42|[이가연](이가연.md)|
|43|[배진영](배진영.md)|
|44|[여지환](여지환.md)|
|45|[이슬기](이슬기.md)|
|46|[정재훈](정재훈.md)|
|47|[고서영](고서영.md)|
|48|[황치양](황치양.md)|
|49|[임진호](임진호.md)|
|50|[김영우](김영우.md)|

