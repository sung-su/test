# FAQ

* **이미 VM Ware를 설치하여 사용하시는 분들은**
    * Virtual Box 설치하지 않고, VM Ware로 실습을 진행하실 수 있습니다.
    
<br>

* **BeeBox 설치가 안 됩니다.**
    * ‘가상 머신 BeeBox의 세션을 열 수 없습니다.’라는 메시지와 함께 ‘결과 코드: E_FAIL (0x80004005)’인 경우
        * fasoo.com이 깔려있나 확인해 보고, 깔려 있으면 uninstall 후 BeeBox 재설치
	* FSW(Fasoo Secure Web) 프로그램 삭제
	* 만약 RBS 실행 중에 Virtual Box를 설치한 경우,
		* -> rbs 종료 -> vbox 제거 -> 재부팅 -> rbs 없이 vbox설치
<br>

* **VirtualBox 실행 오류가 납니다.**
    * Call to VidMessageSlotMap failed: Last=0xc000000d/87 (VERR_NEM_VM_CREATE_FAILED)
	* 더 높은 버전을 다운받아 재설치
    * 만약 RBS 실행 중에 Virtual Box를 설치한 경우,
        * -> rbs 종료 -> vbox 제거 -> 재부팅 -> rbs 없이 vbox설치
<br>

* **VM 시작이 안 됩니다.**
    * '호스트 시스템에서 하드웨어 가상화를 지원하지 않지만, 시스템 페이지의 가속 부분에서 활성화되어 있습니다. 
	가상 시스템을 시작하려면 해당 설정을 비활성화해야합니다.' 문구가 나옴
	    * hyper-v를 꺼야 됨 (https://webnautes.tistory.com/448 참조)
	    *   HyperV 비활성화 (윈도우에서 확인)
	    *   CPU의 가상화 지원 확인 (바이오스에서 확인)
	    *   Disable 되어 있으면 Enable로 변경합니다, 바이오스는 회사마다 조금씩 다를 수있습니다.
<br>
	
* **bWAPP  접속하면 에러가 발생합니다.**
    * ‘Fatal error: Class 'mysqli' not found in /var/www/bWAPP/connect_i.php on line 23’와 같은 메시지가 나오는 경우
	    * virtual machine 재설치
<br>
	
* **VM에서 ‘호스트 전용 어댑터’ 인식이 안 됩니다.**
    * 재택 근무 중이고, VM ware를 사용했던 이력이 있는 경우
	    * VM ware와 충돌이 일어나고 있을 가능성이 높음. VirtualBox 대신 VM ware로 실습 진행
<br>

* **https://sha1.web-max.ca/ 접속이 안 됩니다.**
    * https://md5decrypt.net/en/Sha1/#answer 이용
<br>

* **Cross-Site Scripting 실습시, alert 창이 뜨지 않습니다.**
    * DOM 시간차로 발생하는 문제일 확률이 높음
	* alert() 앞에 setTimeout(1)을 추가하여 강제로 delay 발생
<br>

* **XML/Xpath Injection 실습시, 구문이 제대로 동작하지 않습니다.**
    * " 가 아니라 ' 로 입력한 것이 맞는지 확인
	* 구문 뒤에 안 보이는 enter 같은 것이 들어가 있지 않은지 확인
	* 편집기가 - 또는 '를 자동으로 다른 문자로 변경하지 않았는지 확인
	* 명령어 편집은 가능한 메모장 사용 권장
<br>

* **Virtual box에서 네트워크 연결되지 않음.**
    * Virtual Host-Only Network interface 삭제후 재설치
	* https://hand-over.tistory.com/18 참고
	
<br>

* **네트워크 설정 -> "호스트 전용 어댑터" 선택하면 "이름" 항목이 선택하지 않음으로 보임.**
    * 재부팅 후 RBS 실행 전 vm 먼저 실행

<br>

* **기계식 키보드인데 Virtual Box의 키보드 모델 설정에 없음.**
    * Generic / Korean 106-Key 설정에서 나갔다 다시 들어오니 동작
    * 또는 putty로 원격 접속
    
<br>

* **FireFox Proxy 미사용 설정 방법.**
    * 설정 - 네트워크 설정 - 프록시 사용 안함 선택 (No Proxy) - 확인
    * https://www.howtogeek.com/293213/how-to-configure-a-proxy-server-in-firefox/

<br>

* **실습 환경 구축 파일 다운로드 링크**
    * 사내에 계신 경우 (모자이크를 통해 다운로드)
        * http://mosaic.sec.samsung.net/kms/comty.do?comtyId=492964550&menuId=561721126&postId=582748901&page=view&type=LIST
    * 사외에 계신 경우
        * https://www.virtualbox.org/wiki/Downloads
        * https://putty.ko.softonic.com/
        * https://sourceforge.net/projects/bwapp/files/bee-box/

    
