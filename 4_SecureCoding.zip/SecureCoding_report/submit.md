# 제출방법

![제출1](result_img/submit1.PNG) <br><br>
![제출2](result_img/submit2.PNG) <br>
----------
![제출3](result_img/submit3.PNG)