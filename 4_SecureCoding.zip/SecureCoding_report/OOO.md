## _**실습 결과**_
<br>

(1) **#4. Buffer Overflow 실습** <br>
* 최종결과 실행후, 한글 또는 영어로 본인 이름 기입된 화면 캡처.
* 실습은 Ubuntu, PuTTY, ... 무엇이든 상관없음.

![실습1](result_img/OOO1.PNG)
<br>

----------
(2) **#6. SQL Injection 실습** <br>
* Character필드에 본인 이름 기입.

![실습2](result_img/OOO2.PNG)
<br>

----------
(3) **#8. XSS 실습** <br>
* 상단 본인이름 표기
* ID/PW 입력칸 작성

![실습3](result_img/OOO3.PNG)
<br>

----------
* **과제** <br>
    * bof.c파일에서 buf 크기를 256 + (사번 % 5) * 16 으로 변경하여 shell을 실행하시오.
    * 최종결과 실행후, 한글 또는 영어로 본인 이름 기입된 화면 캡처.
    
![과제](result_img/OOO과제.PNG)