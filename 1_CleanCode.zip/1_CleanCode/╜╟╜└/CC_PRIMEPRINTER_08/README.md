# Clean Code - PrimePrinter

Observation

- Study PrimePrinterTest class
- create test based on output of program


Activity

- M to numberOfPrimes - introduce field, 
initialize into field declaration
- RR to linesPerPage, introduce field, 
init in field declaration
- CC to columns, introduce field, 
               init in field declaration
- P to primes, introduce field, 
               init in field declaration
- PAGENUMBER to pagenumber, introduce field, 
               init in field declaration
- PAGEOFFSET to pageoffset, introduce field, 
               init in field declaration
- ROWOFSET to rowoffset, introduce field, 
               init in field declaration
- C to column, introduce field, 
               init in field declaration
- J to candidate, introduce field, 
               init in field declaration
- K to primeIndex, introduce field, 
               init in field declaration
- JPRIME to possiblyPrime, introduce field, 
               init in field declaration
- ORD to ord, introduce field, 
               init in field declaration
- SQUARE to square, introduce field, 
               init in field declaration
- N to n, introduce field, 
               init in field declaration
- MULT to multiples, introduce field, 
               init in field declaration
