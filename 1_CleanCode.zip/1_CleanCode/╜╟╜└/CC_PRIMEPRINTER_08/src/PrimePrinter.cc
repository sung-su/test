#include "PrimePrinter.h"
#include "PrimeGenerator.h"
#include <iostream>
#include <iomanip>

void PrimePrinter::print()
{
    const int numberOfPrimes = 1000;
    const int linesPerPage = 50;
    const int columns = 4;
    int column = 0;
    int pagenumber = 1;
    int pageoffset = 1;
    int rowoffset = 0;

    PrimeGenerator pg;
    int* primes = pg.generate(numberOfPrimes);

    while (pageoffset <= numberOfPrimes) {
        std::cout << "The First ";
        std::cout << numberOfPrimes;
        std::cout << " Prime numbers === Page ";        
        std::cout << pagenumber << std::endl;
        std::cout << std::endl;
        
        for (rowoffset = pageoffset; rowoffset <= pageoffset + linesPerPage - 1; rowoffset++) {
            for (column = 0; column <= columns - 1; column++)
                if (rowoffset + column * linesPerPage <= numberOfPrimes)
                    std::cout << std::setw(10) << std::right << primes[rowoffset + column * linesPerPage];
            std::cout << std::endl;
        }
        std::cout << std::endl;

        pagenumber++;
        pageoffset += linesPerPage * columns;
    }
}
