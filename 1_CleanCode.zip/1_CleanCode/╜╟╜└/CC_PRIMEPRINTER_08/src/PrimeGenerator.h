#ifndef _PRIMEGENERATOR_H_
#define _PRIMEGENERATOR_H_

class PrimeGenerator {
	const int maxNumberOfOrd = 30;
	int primeNumberCandidate;
    int ord;
    int square;
	int *primes;
	int *multiples;

	void initializePrimesFirstValue();
	void checkOddNumberForPrime(int n);
	void checkPossiblePrimeCandidate();
	bool isPossiblePrime();
    
public:
	PrimeGenerator()
	{
		multiples = new int [maxNumberOfOrd + 1];
	}
	int* generate(int n);
};

#endif      // _PRIMEGENERATOR_H_
