#ifndef _PRIMEPRINTER_H_
#define _PRIMEPRINTER_H_

class PrimePrinter {

public:
	void print();
};

#endif      // _PRIMEPRINTER_H_
