#include "PrimeGenerator.h"

int* PrimeGenerator::generate(int n)
{
    primes = new int[n + 1];
    initializePrimesFirstValue();
    checkOddNumberForPrime(n);
    return primes;
}

void PrimeGenerator::initializePrimesFirstValue()
{
    primes[1] = 2;
}

void PrimeGenerator::checkOddNumberForPrime(int n)
{
    primeNumberCandidate = 1;
    ord = 2;
    square = 9;
    int primeIndex = 1;

    while (primeIndex < n) {
        checkPossiblePrimeCandidate();
        primeIndex++;
        primes[primeIndex] = primeNumberCandidate;
    }
}

void PrimeGenerator::checkPossiblePrimeCandidate()
{
    do {
        primeNumberCandidate += 2;
        if (primeNumberCandidate == square) {
            ord++;
            square = primes[ord] * primes[ord];
            multiples[ord - 1] = primeNumberCandidate;
        }
        
    } while (!isPossiblePrime());
}

bool PrimeGenerator::isPossiblePrime()
{
    int multipleIndex = 2;
    while (multipleIndex < ord) {
        while (multiples[multipleIndex] < primeNumberCandidate)
            multiples[multipleIndex] += primes[multipleIndex] + primes[multipleIndex];
        if (multiples[multipleIndex] == primeNumberCandidate)
            return false;
        multipleIndex++;
    }
    return true;
}
