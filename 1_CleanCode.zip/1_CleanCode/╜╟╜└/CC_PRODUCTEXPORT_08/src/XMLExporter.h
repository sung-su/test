
#include <string>
#include <vector>
#include "Store.h"
#include "Order.h"

class XMLExporter {
public:
    std::string export_full(std::vector<Order*> orders);
    std::string export_tax_details(std::vector<Order*> orders);
    std::string export_store(Store* store);
    std::string export_history(std::vector<Order*> orders);

private:
    // ToDo: Separate Order Class
    std::string getOrderIdXml(Order*);
    std::string getOrderDateXml(Order*);
    std::string getOrderTotalDollars(Order *);
    std::string getOrderTaxXml(Order *, double);

    // ToDo: Separate Product Class
    std::string getProductIdXml(Product*);
    std::string getProductLocationXml(Product*, Store*);
    std::string getProductWeightXml(Product*);
    std::string getProductStylistXml(Product*);
    std::string stylist_for(Product*);
    std::string getProductPriceXml(Product*);
    double getProductTax(Product*);

    // ToDo: Separate Store Class
    std::string getStoreNameXml(Store*);

    // ToDo: Move to Util Class
    std::string make_formatted_double(double);
};

