#ifndef INVOICE_H
#define INVOICE_H

#include "Performance.h"
#include "Play.h"
#include <string>
#include <vector>
#include <map>
#include <memory>

using std::shared_ptr;
using std::string;
using std::vector;

using namespace std;

class Invoice {
public:
    Invoice(string customer, vector<Performance> performances) 
        : customer_(customer), performances_(performances) {
    }

    int getVolumeCredits(map<string, shared_ptr<Play>> plays);
    float getTotalAmount(map<string, shared_ptr<Play>> plays);
    
    string customer_;
    vector<Performance> performances_;
};

#endif