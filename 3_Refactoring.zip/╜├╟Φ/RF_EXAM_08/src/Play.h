#ifndef PLAY_H
#define PLAY_H

#include <string>
#include <sstream>
#include <cmath>
#include <map>
#include <iostream>
#include <memory>

#include "PlayType.h"

using namespace std;
using std::string;
using std::shared_ptr;

class PlayType;
class Play
{

public:
    Play(string name, string type);
    float amountFor(int audience);
    int getVolumeCredits(int audience);
    string getName();
    string getType();

private:
    shared_ptr<PlayType> p_type;

    string name_;
};

#endif