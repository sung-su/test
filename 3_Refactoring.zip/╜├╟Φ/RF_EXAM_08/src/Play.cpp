#include "Play.h"
#include "PlayType.h"

Play::Play(string name, string type) : name_(name)
{
    p_type = PlayType::create(type);
    p_type->setName(type);
}

float Play::amountFor(int audience)
{
    return p_type->amountFor(audience);
}

int Play::getVolumeCredits(int audience)
{
    return p_type->getVolumeCredits(audience);
}

string Play::getName()
{
    return name_;
}

string Play::getType()
{
    return p_type->getName();
}