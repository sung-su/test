#ifndef PLAYTYPE_H
#define PLAYTYPE_H

#include <memory>
#include "Play.h"

using std::shared_ptr;
using std::string;

class PlayType {
public:
    static shared_ptr<PlayType> create(string);
    virtual void setName(string name) { name_ = name; }
    virtual string getName() { return name_; }
    virtual float amountFor(int audience) = 0;
    virtual int getVolumeCredits(int audience) { return std::max(audience - 30, 0); }

private:
    string name_;
};

class Tragedy : public PlayType {
public:
    virtual float amountFor(int audience) override {
        return audience > 30 ? 40000 + 1000 * (audience - 30) : 40000;
    }
};

class Comedy : public PlayType {
public:
    virtual float amountFor(int audience) override {
        return audience > 20 ? 30000 + 10000 + 500 * (audience - 20) + 300 * audience : 30000 + 300 * audience;
    }

    virtual int getVolumeCredits(int audience) override {
        return std::max(audience - 30, 0) + floor(audience / 5);
    }
};

class Unknown : public PlayType {
public:
    virtual float amountFor(int audience) override {
        throw std::domain_error("unknown type: " + getName());
    }
};

#endif