#ifndef STATEMENTPRINTER_H
#define STATEMENTPRINTER_H

#include "Invoice.h"
#include "Play.h"

#include <map>
#include <memory>

class StatementPrinter {
public:
    std::string print(Invoice, std::map<string, std::shared_ptr<Play>>);
private:
    string printHead(Invoice invoice);
    string printPlayStatement(Invoice invoice, map<string, shared_ptr<Play>> plays);
    string printTail(Invoice invoice, map<string, shared_ptr<Play>> plays);
    string presentPrice(double price);
};


#endif