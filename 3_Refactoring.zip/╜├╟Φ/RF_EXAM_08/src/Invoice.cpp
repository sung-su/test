#include "Invoice.h"

int Invoice::getVolumeCredits(map<string, shared_ptr<Play>> plays)
{
    int volumeCredits = 0;

    for (auto &perf : performances_)
    {
        volumeCredits += plays[perf.playID_]->getVolumeCredits(perf.audience_);
    }

    return volumeCredits;
}

float Invoice::getTotalAmount(map<string, shared_ptr<Play>> plays)
{
    float totalAmount = 0;

    for (auto &perf : performances_)
    {
        totalAmount += plays[perf.playID_]->amountFor(perf.audience_);
    }

    return totalAmount;
}