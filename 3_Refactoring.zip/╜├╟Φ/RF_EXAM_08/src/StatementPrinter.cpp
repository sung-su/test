#include "Performance.h"
#include "StatementPrinter.h"
#include "Play.h"
#include "Invoice.h"

#include <sstream>
#include <cmath>
#include <map>
#include <iostream>
#include <string>

using namespace std;

std::string StatementPrinter::print(Invoice invoice, map<string, shared_ptr<Play>> plays)
{
    std::ostringstream result;
    
    result << printHead(invoice);
    result << printPlayStatement(invoice, plays);
    result << printTail(invoice, plays);

    return result.str();
}

string StatementPrinter::printHead(Invoice invoice)
{
    std::ostringstream result;

    result << "Statement for " << invoice.customer_ << "\n";

    return result.str();
}

string StatementPrinter::printPlayStatement(Invoice invoice, map<string, shared_ptr<Play>> plays)
{
    std::ostringstream result;

    for (auto &perf : invoice.performances_)
    {
        result << "  " << plays[perf.playID_]->getName() << ": $" << presentPrice(plays[perf.playID_]->amountFor(perf.audience_) / 100) << " (" << perf.audience_ << " seats)\n";
    }

    return result.str();
}

string StatementPrinter::printTail(Invoice invoice, map<string, shared_ptr<Play>> plays)
{
    std::ostringstream result;

    result << "Amount owed is $" << presentPrice(invoice.getTotalAmount(plays) / 100.0f) << "\n";
    result << "You earned " << invoice.getVolumeCredits(plays) << " credits\n";

    return result.str();
}

string StatementPrinter::presentPrice(double price)
{
    char buf[20];
    snprintf(buf, 20, "%.2f", price);
    return string(buf);
}