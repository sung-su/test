#include "PlayType.h"

shared_ptr<PlayType> PlayType::create(string type) {
    if ( type == "tragedy" )
        return std::make_shared<Tragedy>();
    if ( type == "comedy" )
        return std::make_shared<Comedy>();

    return std::make_shared<Unknown>();
}