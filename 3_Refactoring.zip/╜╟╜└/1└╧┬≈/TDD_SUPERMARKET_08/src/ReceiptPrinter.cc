﻿#include "ReceiptPrinter.h"
#include <sstream>


string ReceiptPrinter::printReceipt(Receipt& receipt)
{
    string result;
    for (auto& item : receipt.getReceiptItems()) {
        string receiptItem = presentReceiptItem(item);
        result.append(receiptItem);
    }
    for (auto& discount : receipt.getDiscounts()) {
        string discountPresentation = presentDiscount(discount);
        result.append(discountPresentation);
    }
    result.append("\n");
    result.append(presentTotal(receipt));
    return result;
}

string ReceiptPrinter::presentReceiptItem(ReceiptItem& item)
{
    string totalPricePresentation = presentPrice(item.getTotalPrice());
    string name = item.getProduct().getName();

    string line = formatLineWithWhitespace(name, totalPricePresentation);

    if (item.getQuantity() != 1) {
        line += "  " + presentPrice(item.getPrice()) + " * " + presentQuantity(item) + "\n";
    }
    return line;
}

string ReceiptPrinter::presentDiscount(Discount& discount)
{
    string name = discount.getDescription() + "(" + discount.getProduct().getName() + ")";
    string value = "-" + presentPrice(discount.getDiscountAmount()) + "€";

    return formatLineWithWhitespace(name, value);
}

string ReceiptPrinter::presentTotal(Receipt& receipt)
{
    string name = "Total: ";
    string value = presentPrice(receipt.getTotalPrice());
    return formatLineWithWhitespace(name, value);
}

string ReceiptPrinter::formatLineWithWhitespace(string& name, string& value)
{
    string line;
    line.append(name);
    int whitespaceSize = columns - name.length() - value.length();
    for (int i = 0; i < whitespaceSize; i++) {
        line.append(" ");
    }
    line.append(value);
    line.append("\n");
    return line;
}

string ReceiptPrinter::presentPrice(double price)
{
    char buf[20];
    snprintf(buf, 20, "%.2f", price);
    return string(buf);
}

string ReceiptPrinter::presentQuantity(ReceiptItem& item)
{
    char buf[20];    
    if (ProductUnit::Each == item.getProduct().getUnit())
        snprintf(buf, 20, "%x", (int)item.getQuantity());
    else
        snprintf(buf, 20, "%.3f", item.getQuantity());
    return string(buf);
}
