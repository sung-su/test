﻿#ifndef _DISCOUNT_H_
#define _DISCOUNT_H_
#include <string>
#include "Product.h"
#include "Offer.h"

class Discount {
public:
	Discount(Product product, string description, double discountAmount)
		:product(product), description(description), discountAmount(discountAmount) {}
	Discount(const Discount& o);
	Discount() {}
	
	string getDescription() { return description; }
	void setDescription(string desc) { description = desc; }

	double getDiscountAmount() { return discountAmount; }
	void setDiscountAmount(double discount) { discountAmount = discount; }

	Product getProduct() { return product; }
	void setProduct(Product p) { product = p; }

	virtual int getBundlesCount() { return 1; }
	virtual double calculateDiscountAmount(Offer offer, double unitPrice, double quantity) { return 0; }
	virtual string makeDescription(Offer offer) { return ""; }
private:
	string description;
	double discountAmount;
	Product product;
};

class ThreeForTwoDiscount : public Discount {
public:
	virtual int getBundlesCount() override { return 3; }
	virtual double calculateDiscountAmount(Offer offer, double unitPrice, double quantity) override
	{
		return quantity * unitPrice - ((((int)quantity / getBundlesCount()) * 2 * unitPrice) + (int)quantity % 3 * unitPrice);
	}
	virtual string makeDescription(Offer offer) override
	{
		return string("3 for 2 ");
	}
};

class TwoForAmountDiscount : public Discount {
public:
	virtual int getBundlesCount() override { return 2; }
	virtual double calculateDiscountAmount(Offer offer, double unitPrice, double quantity) override
	{
		return unitPrice * quantity - (offer.argument * ((int)quantity / getBundlesCount()) + ((int)quantity % 2) * unitPrice);
	}
	virtual string makeDescription(Offer offer) override
	{
		return string("2 for ") + to_string(offer.argument);
	}
};

class TenPercentDiscount : public Discount {
public:
	virtual double calculateDiscountAmount(Offer offer, double unitPrice, double quantity) override
	{
		return quantity * unitPrice * offer.argument / 100.0;
	}
	virtual string makeDescription(Offer offer) override
	{
		char buf[20];
		snprintf(buf, 20, "%.1f%% off", offer.argument);
		return string(buf);
	}
};

class FiveForAmountDiscount : public Discount {
public:
	virtual int getBundlesCount() override { return 5; }
	virtual double calculateDiscountAmount(Offer offer, double unitPrice, double quantity) override
	{
		return unitPrice * quantity - (offer.argument * ((int)quantity / getBundlesCount()) + (int)quantity % 5 * unitPrice);
	}
	virtual string makeDescription(Offer offer) override
	{
		return to_string(getBundlesCount()) + string(" for ") + to_string(offer.argument);
	}
};

#endif