﻿#ifndef _RECEIPTPRINTER_H_
#define _RECEIPTPRINTER_H_
#include <string>
#include "Receipt.h"
class ReceiptPrinter {
public:
    string printReceipt(Receipt& receipt);
	ReceiptPrinter() :columns(40) {}
	ReceiptPrinter(int columns) :columns(columns) {}
	string presentReceiptItem(ReceiptItem& item);
	string presentDiscount(Discount& discount);
	string presentTotal(Receipt& receipt);
	string formatLineWithWhitespace(string& name, string& value);
	string presentPrice(double price);
	string presentQuantity(ReceiptItem& item);
    
private:
	int columns;
};

#endif
