﻿#include "ShoppingCart.h"
#include <sstream>

void ShoppingCart::addItemQuantity(Product& product, double quantity)
{
	productQuantities[product] += quantity;
}

void ShoppingCart::addDiscountToReceipt(Receipt& receipt, map<string, Offer> & offers, SupermarketCatalog& catalog)
{
	for (auto kv: productQuantities)
	{
		const Product& product = kv.first;
		double unitPrice = catalog.getUnitPrice(product);

		double& quantity = kv.second;
		int quantityAsInt = (int)quantity;

		auto it = offers.find(product.getName());

		if ( it != offers.end())
		{
			auto& offer = it->second;

			if (offer.offerType == SpecialOfferType::ThreeForTwo && quantityAsInt > 2) {
				Discount discount = ThreeForTwoDiscount();
				discount.setProduct(product);
				discount.setDescription(discount.makeDescription(offer));
				discount.setDiscountAmount(discount.calculateDiscountAmount(offer, unitPrice, quantity));
				receipt.addDiscount(discount);
			}
			else if (offer.offerType == SpecialOfferType::TwoForAmount && quantityAsInt >= 2) {
				Discount discount = TwoForAmountDiscount();
				discount.setProduct(product);
				discount.setDescription(discount.makeDescription(offer));
				discount.setDiscountAmount(discount.calculateDiscountAmount(offer, unitPrice, quantity));
				receipt.addDiscount(discount);
			}
			else if (offer.offerType == SpecialOfferType::TenPercentDiscount) {
				Discount discount = TenPercentDiscount();
				discount.setProduct(product);
				discount.setDescription(discount.makeDescription(offer));
				discount.setDiscountAmount(discount.calculateDiscountAmount(offer, unitPrice, quantity));
				receipt.addDiscount(discount);
			}
			else if (offer.offerType == SpecialOfferType::FiveForAmount && quantityAsInt >= 5) {
				Discount discount = FiveForAmountDiscount();
				discount.setProduct(product);
				discount.setDescription(discount.makeDescription(offer));
				discount.setDiscountAmount(discount.calculateDiscountAmount(offer, unitPrice, quantity));
				receipt.addDiscount(discount);
			}
		}
	}
}