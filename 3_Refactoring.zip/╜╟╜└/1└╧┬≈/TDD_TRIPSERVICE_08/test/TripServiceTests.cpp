// TripServiceTests.cpp : Defines the entry point for the console application.
//

#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include <memory>
#include "../src/User.h"
#include "../src/TripService.h"
#include "../src/UserNotLoggedInException.h"
#include "UserSessionAccessor.h"
#include "MockUserSession.h"
#include "MockTripDAO.h"

using namespace testing;

class TripServiceTests : public ::testing::Test {
    protected:
    void SetUp() override {
		mockUserSession = new MockUserSession(); 
		UserSessionAccessor::Set(mockUserSession);
	}

	void TearDown() override {
		UserSessionAccessor::DeleteSession();
    	delete mockUserSession;
	}

	MockUserSession *mockUserSession;
};

TEST_F(TripServiceTests, ShouldThrowExceptionWhenUserNotLoggedIn)
{
	User* NotLoggedUser = nullptr;  

    EXPECT_CALL(*mockUserSession, GetLoggedUser()).
    WillOnce(Return(NotLoggedUser));
	
	TripService<MockTripsDAO> tripService;

	User dummy(1);  //1번 user

	EXPECT_THROW(tripService.GetTripsByUser(dummy), UserNotLoggedInException);
}

TEST_F(TripServiceTests, ReturnEmptyTripsResultWhenUserHasNotFriends)
{
	User loggedUser(1);
	User firstUser(2);

	EXPECT_CALL(*mockUserSession, GetLoggedUser()).
    WillOnce(Return(&loggedUser));
	
	TripService<MockTripsDAO> tripService;

	std::list<Trip> trips;
	EXPECT_EQ(tripService.GetTripsByUser(firstUser), trips);
}

TEST_F(TripServiceTests, ReturnEmptyTripsResultWhenUserIsNotLoggedUserFriend)
{
	User loggedUser(1);
	User firstUser(2);
	User SecondUser(3);
	firstUser.AddFriend(SecondUser);

	Trip trip1(1);
	Trip trip2(2);
	firstUser.AddTrip(trip1);
	SecondUser.AddTrip(trip2);

	EXPECT_CALL(*mockUserSession, GetLoggedUser()).
    WillOnce(Return(&loggedUser));
	
	TripService<MockTripsDAO> tripService;

	std::list<Trip> trips;
	EXPECT_EQ(tripService.GetTripsByUser(firstUser), trips);
}

TEST_F(TripServiceTests, ReturnEmptyTripsResultWhenUserHasNoTrip)
{
	User loggedUser(1);
	User firstUser(2);
	firstUser.AddFriend(loggedUser);

	EXPECT_CALL(*mockUserSession, GetLoggedUser()).
    WillOnce(Return(&loggedUser));
	
	TripService<MockTripsDAO> tripService;

	std::list<Trip> trips;
	EXPECT_EQ(tripService.GetTripsByUser(firstUser), trips);
}

TEST_F(TripServiceTests, ReturnTripsResultWhenUserHasTrips)
{
	User loggedUser(1);
	User firstUser(2);
	firstUser.AddFriend(loggedUser);

	Trip trip1(1);
	Trip trip2(2);
	firstUser.AddTrip(trip1);
	firstUser.AddTrip(trip2);

	EXPECT_CALL(*mockUserSession, GetLoggedUser()).
    WillOnce(Return(&loggedUser));
	
	TripService<MockTripsDAO> tripService;

	std::list<Trip> trips;
	trips.push_back(trip1);
	trips.push_back(trip2);
	EXPECT_EQ(tripService.GetTripsByUser(firstUser), trips);
}

TEST_F(TripServiceTests, IsFriendNegativeTest)
{
	User loggedUser(1);
	User firstUser(2);

	EXPECT_EQ(firstUser.isFriend(loggedUser), false);
}

TEST_F(TripServiceTests, IsFriendPossitiveTest)
{
	User loggedUser(1);
	User firstUser(2);
	firstUser.AddFriend(loggedUser);
	
	EXPECT_EQ(firstUser.isFriend(loggedUser), true);
}