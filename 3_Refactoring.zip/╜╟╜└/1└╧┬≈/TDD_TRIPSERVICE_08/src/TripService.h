#pragma once
#include "Trip.h"
#include <list>
#include "UserNotLoggedInException.h"
#include "UserSession.h"
#include "User.h"
#include "TripDAO.h"
#include "iostream"
using namespace std;


class User;

template<class T>
class TripService
{
public:
	static std::list<Trip> GetTripsByUser(User user);

private:
	static User getLoggedUser();
};

template<class T>
std::list<Trip> TripService<T>::GetTripsByUser(User user)
{
	std::list<Trip> trips;
	
	if (user.isFriend(getLoggedUser()))
	{
		trips = T::FindTripsByUser(user);
	}

	return trips;
}

template<class T>
User TripService<T>::getLoggedUser()
{
	User* user = UserSession::GetInstance()->GetLoggedUser();

	if (!user)
	{
		throw UserNotLoggedInException();
	}

	return *user;
}