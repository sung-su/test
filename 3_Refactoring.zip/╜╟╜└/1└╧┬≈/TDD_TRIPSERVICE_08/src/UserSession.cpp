#include "UserSession.h"

UserSession* UserSession::instance = nullptr;