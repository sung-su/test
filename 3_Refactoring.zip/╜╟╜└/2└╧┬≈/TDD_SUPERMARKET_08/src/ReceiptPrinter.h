﻿#ifndef _RECEIPTPRINTER_H_
#define _RECEIPTPRINTER_H_
#include <string>
#include "Receipt.h"

class ReceiptPrinter
{
private:
	virtual string receiptHead() { return "<table>\n"; }
	virtual string receiptEnding() { return "</table>\n"; }
	virtual string lineBreak() { return "\n"; }
	virtual string presentReceiptItem(ReceiptItem &item) = 0;
	virtual string presentDiscount(Discount &discount) = 0;
	virtual string presentTotal(Receipt &receipt) = 0;
	virtual string formatLineWithWhitespace(string &name, string &value) = 0;

public:
	string printReceipt(Receipt &receipt)
	{
		string result;

		result.append(receiptHead());
		for (auto &item : receipt.getReceiptItems())
		{
			string receiptItem = presentReceiptItem(item);
			result.append(receiptItem);
		}
		for (auto &discount : receipt.getDiscounts())
		{
			string discountPresentation = presentDiscount(discount);
			result.append(discountPresentation);
		}
		result.append(lineBreak());
		result.append(presentTotal(receipt));
		result.append(receiptEnding());

		return result;
	};

	string presentPrice(double price)
	{
		char buf[20];
		snprintf(buf, 20, "%.2f", price);
		return string(buf);
	};

	string presentQuantity(ReceiptItem &item)
	{
		char buf[20];
		if (ProductUnit::Each == item.getProduct().getUnit())
			snprintf(buf, 20, "%x", (int)item.getQuantity());
		else
			snprintf(buf, 20, "%.3f", item.getQuantity());
		return string(buf);
	};
};

#endif
