﻿#include "PaperPrinter.h"
#include <sstream>

string PaperPrinter::receiptHead()
{
    return "";
}
	
string PaperPrinter::receiptEnding()
{
    return "";
}

string PaperPrinter::presentReceiptItem(ReceiptItem& item)
{
    string totalPricePresentation = presentPrice(item.getTotalPrice());
    string name = item.getProduct().getName();

    string line = formatLineWithWhitespace(name, totalPricePresentation);

    if (item.getQuantity() != 1) {
        line += "  " + presentPrice(item.getPrice()) + " * " + presentQuantity(item) + "\n";
    }
    return line;
}

string PaperPrinter::presentDiscount(Discount& discount)
{
    string name = discount.getDescription() + "(" + discount.getProduct().getName() + ")";
    string value = "-" + presentPrice(discount.getDiscountAmount()) + "€";

    return formatLineWithWhitespace(name, value);
}

string PaperPrinter::presentTotal(Receipt& receipt)
{
    string name = "Total: ";
    string value = presentPrice(receipt.getTotalPrice());
    return formatLineWithWhitespace(name, value);
}

string PaperPrinter::formatLineWithWhitespace(string& name, string& value)
{
    string line;
    line.append(name);
    int whitespaceSize = columns - name.length() - value.length();
    for (int i = 0; i < whitespaceSize; i++) {
        line.append(" ");
    }
    line.append(value);
    line.append("\n");
    return line;
}
