﻿#ifndef _PAPERPRINTER_H_
#define _PAPERPRINTER_H_
#include <string>
#include "Receipt.h"
#include "ReceiptPrinter.h"

class PaperPrinter : public ReceiptPrinter {
public:
	PaperPrinter() :columns(40) {}
	PaperPrinter(int columns) :columns(columns) {}
    
private:
	int columns;

	string receiptHead() override;
	string receiptEnding() override;
	string presentReceiptItem(ReceiptItem& item) override;
	string presentDiscount(Discount& discount) override;
	string presentTotal(Receipt& receipt) override;
	string formatLineWithWhitespace(string& name, string& value) override;

};

#endif
