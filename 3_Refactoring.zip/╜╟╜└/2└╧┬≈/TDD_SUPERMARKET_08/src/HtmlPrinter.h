﻿#ifndef _HTMLPRINTER_H_
#define _HTMLPRINTER_H_
#include <string>
#include "Receipt.h"
#include "ReceiptPrinter.h"

class HtmlPrinter : public ReceiptPrinter {
private:
	string lineBreak() override;
	string presentReceiptItem(ReceiptItem& item) override;
	string presentDiscount(Discount& discount) override;
	string presentTotal(Receipt& receipt) override;
	string formatLineWithWhitespace(string& name, string& value) override;

};

#endif
