﻿#include "HtmlPrinter.h"
#include <sstream>

string HtmlPrinter::lineBreak()
{
    return "";
}

string HtmlPrinter::presentReceiptItem(ReceiptItem& item)
{
    string totalPricePresentation = presentPrice(item.getTotalPrice());
    string name = item.getProduct().getName();

    string line = formatLineWithWhitespace(name, totalPricePresentation);

    if (item.getQuantity() != 1) {
        line += "<tr><td colspan=2>" + presentPrice(item.getPrice()) + " * " + presentQuantity(item) + "</td></tr>\n";
    }
    return line;
}

string HtmlPrinter::presentTotal(Receipt& receipt)
{
    string name = "<b>Total: ";
    string value = presentPrice(receipt.getTotalPrice());
    return formatLineWithWhitespace(name, value) + "<tr><td colspan=2>&nbsp;<td></tr>\n";
}

string HtmlPrinter::formatLineWithWhitespace(string& name, string& value)
{
    string line(name);

    line.append("<tr><td>");
    line.append(name);
    line.append("</td><td>");
    line.append(value);
    line.append("</td></tr>\n");
    
    return line;
}

string HtmlPrinter::presentDiscount(Discount& discount)
{
    string name = discount.getDescription() + "(" + discount.getProduct().getName() + ")";
    string value = "-" + presentPrice(discount.getDiscountAmount());

    return formatLineWithWhitespace(name, value);
}