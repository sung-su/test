// Include header files for test frameworks 
#include <gtest/gtest.h>
#include <ApprovalTests.hpp>

// Include code to be tested
#include "../src/SupermarketCatalog.h"
#include "../src/Product.h"
#include "../src/Teller.h"
#include "../src/ShoppingCart.h"
#include "../src/Receipt.h"
#include "../src/PaperPrinter.h"
#include "../src/HtmlPrinter.h"
#include "FakeCatalog.h"

TEST(SupermarketTextPrinterApprovalTests, Verify) {
    FakeCatalog catalog;
    Product toothbrush("toothbrush", ProductUnit::Each);
    Product apples("apples", ProductUnit::Kilo);
    Product rice("rice", ProductUnit::Each);
    Product tubesOfToothpaste("tubesOfToothpaste", ProductUnit::Each);
    Product cherryTomatoes("cherryTomatoes", ProductUnit::Each);
    Product carrot("carrot", ProductUnit::Kilo);

    catalog.addProduct(toothbrush, 0.99);
    catalog.addProduct(apples, 1.99);
    catalog.addProduct(toothbrush, 0.99);
    catalog.addProduct(rice, 2.49);
    catalog.addProduct(tubesOfToothpaste, 1.79);
    catalog.addProduct(cherryTomatoes, 0.69);
    catalog.addProduct(carrot, 2.54);

    Teller teller(catalog);
    teller.addSpecialOffer(SpecialOfferType::ThreeForTwo, toothbrush, 0.0);
    teller.addSpecialOffer(SpecialOfferType::TenPercentDiscount, apples, 20.0);
    teller.addSpecialOffer(SpecialOfferType::TenPercentDiscount, rice, 10.0);
    teller.addSpecialOffer(SpecialOfferType::TwoForAmount, cherryTomatoes, 0.99);
    teller.addSpecialOffer(SpecialOfferType::FiveForAmount, tubesOfToothpaste, 7.49);

    ShoppingCart cart;
    cart.addItemQuantity(toothbrush, 6.0);
    cart.addItemQuantity(apples, 2.5);
    cart.addItemQuantity(rice, 3.0);
    cart.addItemQuantity(cherryTomatoes, 5.0);
    cart.addItemQuantity(tubesOfToothpaste, 6.0);
    cart.addItemQuantity(carrot, 1.2);

    Receipt receipt;
    teller.checksOutArticlesFrom(cart, receipt);

    ReceiptPrinter *printer = new PaperPrinter();
    std::string result = printer->printReceipt(receipt);

    ApprovalTests::Approvals::verify(result);
}

TEST(SupermarketHtmlPrinterApprovalTests, Verify) {
    FakeCatalog catalog;
    Product toothbrush("toothbrush", ProductUnit::Each);
    Product apples("apples", ProductUnit::Kilo);
    Product rice("rice", ProductUnit::Each);
    Product tubesOfToothpaste("tubesOfToothpaste", ProductUnit::Each);
    Product cherryTomatoes("cherryTomatoes", ProductUnit::Each);
    Product carrot("carrot", ProductUnit::Kilo);

    catalog.addProduct(toothbrush, 0.99);
    catalog.addProduct(apples, 1.99);
    catalog.addProduct(toothbrush, 0.99);
    catalog.addProduct(rice, 2.49);
    catalog.addProduct(tubesOfToothpaste, 1.79);
    catalog.addProduct(cherryTomatoes, 0.69);
    catalog.addProduct(carrot, 2.54);

    Teller teller(catalog);
    teller.addSpecialOffer(SpecialOfferType::ThreeForTwo, toothbrush, 0.0);
    teller.addSpecialOffer(SpecialOfferType::TenPercentDiscount, apples, 20.0);
    teller.addSpecialOffer(SpecialOfferType::TenPercentDiscount, rice, 10.0);
    teller.addSpecialOffer(SpecialOfferType::TwoForAmount, cherryTomatoes, 0.99);
    teller.addSpecialOffer(SpecialOfferType::FiveForAmount, tubesOfToothpaste, 7.49);

    ShoppingCart cart;
    cart.addItemQuantity(toothbrush, 6.0);
    cart.addItemQuantity(apples, 2.5);
    cart.addItemQuantity(rice, 3.0);
    cart.addItemQuantity(cherryTomatoes, 5.0);
    cart.addItemQuantity(tubesOfToothpaste, 6.0);
    cart.addItemQuantity(carrot, 1.2);

    Receipt receipt;
    teller.checksOutArticlesFrom(cart, receipt);

    ReceiptPrinter *printer = new HtmlPrinter();
    std::string result = printer->printReceipt(receipt);

    ApprovalTests::Approvals::verifyWithExtension(result, ".html");
}