#ifndef EMPLOYEETYPE_H
#define EMPLOYEETYPE_H

#include <memory>
#include "Employee.h"

using std::shared_ptr;

class EmployeeType {
public:
    static const int ENGINEER = 0;
    static const int SALESMAN = 1;
    static const int MANAGER = 2;

    static shared_ptr<EmployeeType> create(int);
    virtual int payAmount(Employee&) = 0; 
};

class Engineer : public EmployeeType {
public:
    virtual int payAmount(Employee& employee) override{
        return employee.m_monthlySalary;        
    }    
};


class Salesman : public EmployeeType {
public:
    virtual int payAmount(Employee& employee) override{
        return employee.m_monthlySalary + employee.m_commission;
    }
};

class Manager : public EmployeeType {
public:
    virtual int payAmount(Employee& employee) override{
        return employee.m_monthlySalary + employee.m_bonus;
    }
};

#endif






