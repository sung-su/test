#include <memory>
#include <iostream>
#include "Employee.h"
#include "EmployeeType.h"

Employee::Employee(int arg)
{        
    setType(arg);
};

void Employee::setType(int type) {
    m_type = EmployeeType::create(type);
}

int Employee::payAmount() {
    return m_type->payAmount(*this);
}




