#include <gtest/gtest.h>
#include <iostream>
#include "Employee.h"

using namespace std;

using testing::InitGoogleTest;
using testing::Test;
using testing::TestCase;

constexpr static int ENGINEER = 1;
constexpr static int SALESMAN = 2;
constexpr static int MANAGER = 3;


shared_ptr<Employee> createEmployee(int type) {
    switch(type) {
        case ENGINEER:
            return make_shared<Engineer>(type);
        case SALESMAN:
            return make_shared<Salesman>(type);
        case MANAGER:
            return make_shared<Manager>(type);
        default:
            throw TypeException();;
    }
}


TEST(employeeTest, testEngineerSalary) {
    auto e = createEmployee(ENGINEER);
    ASSERT_EQ(2000, e->payAmount());    
}

TEST(employeeTest, testSalesmanSalary) {
    auto e = createEmployee(SALESMAN);
    ASSERT_EQ(2500, e->payAmount());
}

TEST(employeeTest, testManagerSalary) {
    auto e = createEmployee(MANAGER);
    ASSERT_EQ(3000, e->payAmount());
}

TEST(employeeTest, testWrongEmployeeType) {
    ASSERT_THROW(createEmployee(100), TypeException);    
}


int main(int argc, char **argv) {
    InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
