#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <memory>

class Employee {
public:

    Employee(int type) : m_type(type){};      
    virtual int payAmount() { return 0; }; 
    
    int m_monthlySalary = 2000;
    int m_commission = 500;
    int m_bonus = 1000;   

private:
    int getType();  
    void setType(int);
    int m_type;
};


class Engineer : public Employee {
public:
    Engineer(int type) : Employee(type) {};
    int payAmount() { return m_monthlySalary; }   
};


class Salesman : public Employee {
public:
    Salesman(int type) : Employee(type) {};
    int payAmount() { return m_monthlySalary + m_commission; }
};

class Manager : public Employee {
public:
    Manager(int type) : Employee(type) {}; 
    int payAmount() { return m_monthlySalary + m_bonus; }
};

class TypeException : public std::exception{
public:
    virtual const char* what() {
        return "employee type mismatching";
    } 
};

#endif

