#include "GildedRose.h"

GildedRose::GildedRose(vector<shared_ptr<Item>> &items) : items(items)
{
}

shared_ptr<Item> Item::createItem(string name, int sellIn, int quality)
{
    if (name == "Aged Brie")
        return make_shared<AgedBrie>(name, sellIn, quality);
    if (name == "Backstage passes to a TAFKAL80ETC concert")
        return make_shared<BackstagePasses>(name, sellIn, quality);
    if (name == "Sulfuras, Hand of Ragnaros")
        return make_shared<Sulfuras>(name, sellIn, quality);
    
    return make_shared<NormalItem>(name, sellIn, quality);
}

void GildedRose::updateQuality()
{
    for (int i = 0; i < items.size(); i++)
    {
        items[i]->updateItemQuality();
    }
}

void AgedBrie::updateItemQuality()
{
    descreasSellIn();

    if (quality >= 50)
        return;

    increaseQuality();

    if (sellIn < 0)
    {
        increaseQuality();
    }
}

void BackstagePasses::updateItemQuality()
{
    descreasSellIn();

    if (sellIn < 0)
    {
        quality = 0;
        return;
    }

    if (quality >= 50)
        return;

    increaseQuality();

    if (sellIn <= 11)
    {
        increaseQuality();
    }
    if (sellIn <= 6)
    {
        increaseQuality();
    }
}

void NormalItem::updateItemQuality()
{
    descreasSellIn();

    if (quality <= 0)
        return;

    decreaseQuality();

    if (sellIn < 0)
    {
        decreaseQuality();
    }
}