#include <string>
#include <vector>
#include <memory>

using namespace std;

class Item
{
public:
    string name;
    int sellIn;
    int quality;
    Item(string name, int sellIn, int quality) : name(name), sellIn(sellIn), quality(quality)
    {
    }
    virtual void updateItemQuality() {}
    static shared_ptr<Item> createItem(string name, int sellIn, int quality);
    void increaseQuality() { quality = quality + 1; }
    void decreaseQuality() { quality = quality - 1; }
    void descreasSellIn() { sellIn = sellIn - 1; }
};

class AgedBrie : public Item
{
public:
    AgedBrie(string name, int sellIn, int quality) : Item(name, sellIn, quality) {}
    void updateItemQuality() override;
};

class BackstagePasses : public Item
{
public:
    BackstagePasses(string name, int sellIn, int quality) : Item(name, sellIn, quality) {}
    void updateItemQuality() override;
};

class Sulfuras : public Item
{
public:
    Sulfuras(string name, int sellIn, int quality) : Item(name, sellIn, quality) {}
    void updateItemQuality() override {};
};

class NormalItem : public Item
{
public:
    NormalItem(string name, int sellIn, int quality) : Item(name, sellIn, quality) {}
    void updateItemQuality() override;
};

class GildedRose
{
public:
    vector<shared_ptr<Item>> &items;
    GildedRose(vector<shared_ptr<Item>> &items);

    void updateQuality();
};
