#include <gtest/gtest.h>

#include "../src/GildedRose.h"

// Item name test
TEST(GildedRoseTest, ItemNameTest) {
    vector<shared_ptr<Item>> items;
    items.push_back(Item::createItem("+5 Dexterity Vest", 10, 20));
    items.push_back(Item::createItem("Sulfuras, Hand of Ragnaros", 0, 80));
    items.push_back(Item::createItem("Aged Brie", 2, 0));
    items.push_back(Item::createItem("Backstage passes to a TAFKAL80ETC concert", 15, 20));
    GildedRose app(items);
    app.updateQuality();
    EXPECT_STREQ("+5 Dexterity Vest", app.items[0]->name.c_str());
    EXPECT_STREQ("Sulfuras, Hand of Ragnaros", app.items[1]->name.c_str());
    EXPECT_STREQ("Aged Brie", app.items[2]->name.c_str());
    EXPECT_STREQ("Backstage passes to a TAFKAL80ETC concert", app.items[3]->name.c_str());
}

// Item quality value test
TEST(GildedRoseTest, ItemQualityNegativeValueTest) {
    vector<shared_ptr<Item>> items;
    items.push_back(Item::createItem("+5 Dexterity Vest", 10, -1));
    items.push_back(Item::createItem("Sulfuras, Hand of Ragnaros", 10, -1));
    items.push_back(Item::createItem("Aged Brie", 2, -1));
    items.push_back(Item::createItem("Backstage passes to a TAFKAL80ETC concert", 15, -1));
    GildedRose app(items);
    app.updateQuality();
    EXPECT_EQ(-1, app.items[0]->quality);
    EXPECT_EQ(-1, app.items[1]->quality);
    EXPECT_EQ(0, app.items[2]->quality);
    EXPECT_EQ(0, app.items[3]->quality);
}

TEST(GildedRoseTest, ItemQualityZeroValueTest) {
    vector<shared_ptr<Item>> items;
    items.push_back(Item::createItem("+5 Dexterity Vest", 10, 0));
    items.push_back(Item::createItem("Sulfuras, Hand of Ragnaros", 10, 0));
    items.push_back(Item::createItem("Aged Brie", 2, 0));
    items.push_back(Item::createItem("Backstage passes to a TAFKAL80ETC concert", 15, 0));
    GildedRose app(items);
    app.updateQuality();
    EXPECT_EQ(0, app.items[0]->quality);
    EXPECT_EQ(0, app.items[1]->quality);
    EXPECT_EQ(1, app.items[2]->quality);
    EXPECT_EQ(1, app.items[3]->quality);
}

TEST(GildedRoseTest, ItemQualityPossitiveValueTest) {
    vector<shared_ptr<Item>> items;
    items.push_back(Item::createItem("+5 Dexterity Vest", 10, 5));
    items.push_back(Item::createItem("Sulfuras, Hand of Ragnaros", 10, 80));
    items.push_back(Item::createItem("Aged Brie", 2, 1));
    items.push_back(Item::createItem("Backstage passes to a TAFKAL80ETC concert", 15, 20));
    GildedRose app(items);
    app.updateQuality();
    EXPECT_EQ(4, app.items[0]->quality);
    EXPECT_EQ(80, app.items[1]->quality);
    EXPECT_EQ(2, app.items[2]->quality);
    EXPECT_EQ(21, app.items[3]->quality);
}

TEST(GildedRoseTest, ItemQualityValueMaxTest) {
    vector<shared_ptr<Item>> items;
    items.push_back(Item::createItem("+5 Dexterity Vest", 10, 50));
    items.push_back(Item::createItem("Sulfuras, Hand of Ragnaros", 0, 80));
    items.push_back(Item::createItem("Aged Brie", 1, 50));
    items.push_back(Item::createItem("Backstage passes to a TAFKAL80ETC concert", 15, 50));
    GildedRose app(items);
    app.updateQuality();
    EXPECT_EQ(49, app.items[0]->quality);
    EXPECT_EQ(80, app.items[1]->quality);
    EXPECT_EQ(50, app.items[2]->quality);
    EXPECT_EQ(50, app.items[3]->quality);
}

TEST(GildedRoseTest, ItemQualityValueOutSellInTest) {
    vector<shared_ptr<Item>> items;
    items.push_back(Item::createItem("+5 Dexterity Vest", 0, 20));
    items.push_back(Item::createItem("Sulfuras, Hand of Ragnaros", 0, 80));
    items.push_back(Item::createItem("Aged Brie", 0, 1));
    items.push_back(Item::createItem("Backstage passes to a TAFKAL80ETC concert", 0, 20));
    GildedRose app(items);
    app.updateQuality();
    EXPECT_EQ(18, app.items[0]->quality);
    EXPECT_EQ(80, app.items[1]->quality);
    EXPECT_EQ(3, app.items[2]->quality);
    EXPECT_EQ(0, app.items[3]->quality);
}

// Backstage pass item quality with sellin test
TEST(GildedRoseTest, BackstagePassItemQualityValueOver11Test) {
    vector<shared_ptr<Item>> items;
    items.push_back(Item::createItem("Backstage passes to a TAFKAL80ETC concert", 15, 20));
    GildedRose app(items);
    app.updateQuality();
    EXPECT_EQ(21, app.items[0]->quality);
}

TEST(GildedRoseTest, BackstagePassItemQualityValueWithIn10Test) {
    vector<shared_ptr<Item>> items;
    items.push_back(Item::createItem("Backstage passes to a TAFKAL80ETC concert", 10, 20));
    GildedRose app(items);
    app.updateQuality();
    EXPECT_EQ(22, app.items[0]->quality);
}

TEST(GildedRoseTest, BackstagePassItemQualityValueWithIn5Test) {
    vector<shared_ptr<Item>> items;
    items.push_back(Item::createItem("Backstage passes to a TAFKAL80ETC concert", 5, 20));
    GildedRose app(items);
    app.updateQuality();
    EXPECT_EQ(23, app.items[0]->quality);
}

TEST(GildedRoseTest, BackstagePassItemQualityValueSellInOverTest) {
    vector<shared_ptr<Item>> items;
    items.push_back(Item::createItem("Backstage passes to a TAFKAL80ETC concert", 0, 20));
    GildedRose app(items);
    app.updateQuality();    
    EXPECT_EQ(0, app.items[0]->quality);
}

// Item sellin value test
TEST(GildedRoseTest, ItemSellInNegativeValueTest) {
    vector<shared_ptr<Item>> items;
    items.push_back(Item::createItem("+5 Dexterity Vest", -1, 20));
    items.push_back(Item::createItem("Sulfuras, Hand of Ragnaros", -1, 80));
    items.push_back(Item::createItem("Aged Brie", -1, 0));
    items.push_back(Item::createItem("Backstage passes to a TAFKAL80ETC concert", -1, 20));
    GildedRose app(items);
    app.updateQuality();
    EXPECT_EQ(-2, app.items[0]->sellIn);
    EXPECT_EQ(-1, app.items[1]->sellIn);
    EXPECT_EQ(-2, app.items[2]->sellIn);
    EXPECT_EQ(-2, app.items[3]->sellIn);
}

TEST(GildedRoseTest, ItemSellInZeroValueTest) {
    vector<shared_ptr<Item>> items;
    items.push_back(Item::createItem("+5 Dexterity Vest", 0, 20));
    items.push_back(Item::createItem("Sulfuras, Hand of Ragnaros", 0, 80));
    items.push_back(Item::createItem("Aged Brie", 0, 0));
    items.push_back(Item::createItem("Backstage passes to a TAFKAL80ETC concert", 0, 20));
    GildedRose app(items);
    app.updateQuality();
    EXPECT_EQ(-1, app.items[0]->sellIn);
    EXPECT_EQ(0, app.items[1]->sellIn);
    EXPECT_EQ(-1, app.items[2]->sellIn);
    EXPECT_EQ(-1, app.items[3]->sellIn);
}

TEST(GildedRoseTest, ItemSellInPossitiveValueTest) {
    vector<shared_ptr<Item>> items;
    items.push_back(Item::createItem("+5 Dexterity Vest", 5, 20));
    items.push_back(Item::createItem("Sulfuras, Hand of Ragnaros", 10, 80));
    items.push_back(Item::createItem("Aged Brie", 2, 0));
    items.push_back(Item::createItem("Backstage passes to a TAFKAL80ETC concert", 15, 20));
    GildedRose app(items);
    app.updateQuality();
    EXPECT_EQ(4, app.items[0]->sellIn);
    EXPECT_EQ(10, app.items[1]->sellIn);
    EXPECT_EQ(1, app.items[2]->sellIn);
    EXPECT_EQ(14, app.items[3]->sellIn);
}


