#include "../src/GildedRose.h"

#include <iostream>

using namespace std;

ostream& operator<<(ostream& s, Item& item)
{
    s << item.name << ", " << item.sellIn << ", " << item.quality;
    return s;
}

std::ostream& operator<<(ostream& s, const shared_ptr<Item>& item)
{
    s << item->name << ", " << item->sellIn << ", " << item->quality;
    return s;
}

int main()
{
    vector<shared_ptr<Item>> items;
    items.push_back(Item::createItem("+5 Dexterity Vest", 10, 20));
    items.push_back(Item::createItem("Aged Brie", 2, 0));
    items.push_back(Item::createItem("Elixir of the Mongoose", 5, 7));
    items.push_back(Item::createItem("Sulfuras, Hand of Ragnaros", 0, 80));
    items.push_back(Item::createItem("Sulfuras, Hand of Ragnaros", -1, 80));
    items.push_back(Item::createItem("Backstage passes to a TAFKAL80ETC concert", 15, 20));
    items.push_back(Item::createItem("Backstage passes to a TAFKAL80ETC concert", 10, 49));
    items.push_back(Item::createItem("Backstage passes to a TAFKAL80ETC concert", 5, 49));
    // this Conjured item doesn't yet work properly
    items.push_back(Item::createItem("Conjured Mana Cake", 3, 6));
    
    GildedRose app(items);

    cout << "OMGHAI!" << endl;

    for (int day = 0; day <= 30; day++)
    {
        cout << "-------- day " << day << " --------" << endl;
        cout << "name, sellIn, quality" << endl;
        for (vector<shared_ptr<Item>>::iterator i = items.begin(); i != items.end(); i++)
        {
            cout << *i << endl;
        }
        cout << endl;

        app.updateQuality();
    }
}
