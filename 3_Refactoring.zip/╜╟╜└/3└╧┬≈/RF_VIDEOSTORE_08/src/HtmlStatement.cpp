﻿#include "HtmlStatement.h"
#include <string>

string HtmlStatement::printHeader(Customer customer)
{
    std::ostringstream result;
    result << "<H1>Rentals for <EM>" << customer.getName() << "</EM></H1><P>\n";
    return result.str();
}

string HtmlStatement::printBody(Customer customer)
{
    std::ostringstream result;
    
    for (auto &rental : customer.getRentals())
    {
        result << "&nbsp;&nbsp;&nbsp;&nbsp;" << rental.getMovie().getTitle() << " : "<< rental.getMovie().amountFor(rental.getDaysRented()) << "<BR>\n";
    }

    return result.str();
}

string HtmlStatement::printTail(Customer customer)
{
    std::ostringstream result;

    result << "<P>Amount owed is <EM>" << customer.getTotalAmount() << "</EM><P>\n";
    result << "You earned <EM>" << customer.getFrequentRenterPoints() << "</EM> frequent renter points<P>";

    return result.str();
}