// Movie.hh
#ifndef MOVIE_H
#define MOVIE_H
#include <string>
#include <memory>

using std::shared_ptr;

class MovieType;
class Movie {
public:
  static const int CHILDRENS   = 2;
  static const int REGULAR     = 0;
  static const int NEW_RELEASE = 1;
  static const int Best_Seller = 3;

  Movie( const std::string& title, int priceCode = REGULAR );

  int getPriceCode() const;
  void setPriceCode(int arg);
  std::string getTitle() const;
  double amountFor(int daysRented) const;
  int getFrequentRenterPoint(int daysRented) const;

private:
  std::string movieTitle;
  int moviePriceCode;
  shared_ptr<MovieType> m_type;

};

class TypeException : public std::exception{
public:
    virtual const char* what() {
        return "movie type mismatching";
    } 
};

#endif // MOVIE_H
