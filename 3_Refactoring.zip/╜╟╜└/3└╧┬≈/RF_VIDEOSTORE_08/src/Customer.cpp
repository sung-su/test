// Customer.cc
#include <sstream>
#include <vector>
#include "Customer.h"
#include "Movie.h"

using std::ostringstream;
using std::vector;

int Customer::getFrequentRenterPoints()
{
  int frequentRenterPoints = 0;

  std::vector<Rental>::iterator iter = customerRentals.begin();
  std::vector<Rental>::iterator iter_end = customerRentals.end();

  // Loop over to calculate frequent rental points
  for (; iter != iter_end; ++iter)
  {
    Rental each = *iter;

    // Add frequent renter points
    frequentRenterPoints += each.getMovie().getFrequentRenterPoint(each.getDaysRented());
  }

  return frequentRenterPoints;
}

double Customer::getTotalAmount()
{
  double totalAmount = 0.;

  std::vector<Rental>::iterator iter = customerRentals.begin();
  std::vector<Rental>::iterator iter_end = customerRentals.end();

  // Loop over to calculate total amount
  for (; iter != iter_end; ++iter)
  {
    Rental each = *iter;
    Movie movie = each.getMovie();

    totalAmount += each.getMovie().amountFor(each.getDaysRented());
  }

  return totalAmount;
}

std::vector<Rental> Customer::getRentals()
{
  return customerRentals;
}