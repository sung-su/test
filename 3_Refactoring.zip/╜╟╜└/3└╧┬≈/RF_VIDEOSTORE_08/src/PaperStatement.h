﻿#ifndef _PAPERSTATEMENT_H_
#define _PAPERSTATEMENT_H_
#include <string>
#include "CustomerStatement.h"

class PaperStatement : public CustomerStatement {
   
private:
	string printHeader(Customer customer) override;
	string printBody(Customer customer) override;
	string printTail(Customer customer) override;

};

#endif
