﻿#include "PaperStatement.h"
#include <string>

string PaperStatement::printHeader(Customer customer)
{
    std::ostringstream result;
    result << "Rental Record for " << customer.getName() << "\n";
    return result.str();
}

string PaperStatement::printBody(Customer customer)
{
    std::ostringstream result;

    for (auto &rental : customer.getRentals())
    {
        result << "\t" << rental.getMovie().getTitle() << "\t" << rental.getMovie().amountFor(rental.getDaysRented()) << std::endl;
    }
    
    return result.str();
}

string PaperStatement::printTail(Customer customer)
{
    std::ostringstream result;

    result << "Amount owed is " << customer.getTotalAmount() << "\n";
    result << "You earned " << customer.getFrequentRenterPoints() << " frequent renter points";
    
    return result.str();
}