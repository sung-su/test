﻿#ifndef _STATEMENT_H_
#define _STATEMENT_H_
#include <sstream>
#include <string>
#include <vector>
#include "Customer.h"

using std::ostringstream;
using std::vector;
using std::string;

class CustomerStatement
{
private:
	virtual string printHeader(Customer customer) = 0;
	virtual string printBody(Customer customer) = 0;
	virtual string printTail(Customer customer) = 0;

public:
	string printStatement(Customer customer)
	{
		std::ostringstream result;

  		result << printHeader(customer);
		result << printBody(customer);
		result << printTail(customer);

		return result.str();
	};
};

#endif
