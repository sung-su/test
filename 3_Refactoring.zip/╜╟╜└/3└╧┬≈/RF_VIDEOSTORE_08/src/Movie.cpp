// Movie.cpp
#include "Movie.h"
#include "MovieType.h"

Movie::Movie( const std::string& title, int priceCode ): 
    movieTitle( title ),
    moviePriceCode( priceCode )
{
    setPriceCode(priceCode);
}

int Movie::getPriceCode() const
{
    return moviePriceCode;
}

void Movie::setPriceCode(int arg)
{
    m_type = MovieType::create(arg);
}

std::string Movie::getTitle() const
{
    return movieTitle;
}

double Movie::amountFor(int daysRented) const
{
    return m_type->amountFor(daysRented);
}

int Movie::getFrequentRenterPoint(int daysRented) const
{
    return m_type->getFrequentRenterPoint(daysRented);
}