﻿#ifndef _HTMLSTATEMENT_H_
#define _HTMLSTATEMENT_H_
#include <string>
#include "CustomerStatement.h"

class HtmlStatement : public CustomerStatement {
   
private:
	string printHeader(Customer customer) override;
	string printBody(Customer customer) override;
	string printTail(Customer customer) override;

};

#endif
