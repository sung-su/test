#ifndef MOVIETYPE_H
#define MOVIETYPE_H

#include <memory>
#include "Movie.h"

using std::shared_ptr;

class MovieType {
public:
    static shared_ptr<MovieType> create(int);
    virtual double amountFor(int daysRented) = 0;
    virtual int getFrequentRenterPoint(int daysRented) { return 1; }
};

class Childrens : public MovieType {
public:
    virtual double amountFor(int daysRented) override {
        return daysRented > 3 ? 1.5 + (daysRented - 3) * 1.5 : 1.5;
    }
};

class Regular : public MovieType {
public:
    virtual double amountFor(int daysRented) override {
        return daysRented > 2 ? 2. + (daysRented - 2) * 1.5 : 2.;
    }
};

class NewRelease : public MovieType {
public:
    virtual double amountFor(int daysRented) override {
        return daysRented * 3;
    }
    virtual int getFrequentRenterPoint(int daysRented) override {
        return daysRented > 1 ? 2 : 1;
    }
};

class BestSeller : public MovieType {
public:
    virtual double amountFor(int daysRented) override {
        return daysRented > 2 ? 5 * daysRented + 2.5 * (daysRented - 2) : 5 * daysRented;
    }
    virtual int getFrequentRenterPoint(int daysRented) override {
        return 5 * daysRented;
    }
};

class Unknown : public MovieType {
public:
    virtual double amountFor(int daysRented) override {
        return 0.;
    }
};

#endif