#include "MovieType.h"

shared_ptr<MovieType> MovieType::create(int type) {
    if( type == Movie::CHILDRENS )
        return std::make_shared<Childrens>();
    if( type == Movie::REGULAR )
        return std::make_shared<Regular>();
    if( type == Movie::NEW_RELEASE )
        return std::make_shared<NewRelease>();
    if( type == Movie::Best_Seller )
        return std::make_shared<BestSeller>();

    return std::make_shared<Unknown>();
}