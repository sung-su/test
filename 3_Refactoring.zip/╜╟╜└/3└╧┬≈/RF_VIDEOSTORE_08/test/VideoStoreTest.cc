// Include header files for test frameworks 
#include <gtest/gtest.h>
#include <ApprovalTests.hpp>

#include "../src/Movie.h"
#include "../src/Rental.h"
#include "../src/Customer.h"
#include "../src/CustomerStatement.h"
#include "../src/PaperStatement.h"
#include "../src/HtmlStatement.h"

using namespace std;

namespace VideoStoreTests { 
    TEST( VideoStoreTest, fail_test ) {
        //FAIL();
    }

    Movie regular1{ "삼시세끼 정선편", Movie::REGULAR };
    Movie regular2{ "삼시세끼 어촌편", Movie::REGULAR };
    Movie newRelease1{ "삼시세끼 바다목장편", Movie::NEW_RELEASE };
    Movie newRelease2{ "삼시세끼 산촌편",Movie::NEW_RELEASE };
    Movie children1{ "삼시네세끼", Movie::CHILDRENS };
    Movie children2{ "삼시네세끼", Movie::CHILDRENS };
    Movie bestSeller1{ "신서유기5", Movie::Best_Seller };
    Movie bestSeller2{ "신서유기6", Movie::Best_Seller };
    Movie unknown1{ "삼시세끼 달나라편", 100 };
    Customer customer{"John"};

    class VideoStoreTestFixture : public ::testing::Test {    
    protected:
        static void SetUpTestCase() {
        customer.addRental( {regular1, 2} );
        customer.addRental( {regular2, 3} );
        customer.addRental( {newRelease1, 1} );
        customer.addRental( {newRelease2, 2} );
        customer.addRental( {children1, 3} );
        customer.addRental( {children2, 4} );
        customer.addRental( {bestSeller1, 2} );
        customer.addRental( {bestSeller2, 3} );
        customer.addRental( {unknown1, 5} );
        }

    };

    TEST_F(VideoStoreTestFixture, UnitTest1) {
        ASSERT_TRUE(true);
    }

    TEST_F(VideoStoreTestFixture, testsatement) {
        CustomerStatement *statement = new PaperStatement();
        std::string receipt = statement->printStatement(customer);
        ApprovalTests::Approvals::verify(receipt);
    }
    
    TEST_F(VideoStoreTestFixture, testHtmlsatement) {
        CustomerStatement *statement = new HtmlStatement();
        std::string receipt = statement->printStatement(customer);
        ApprovalTests::Approvals::verify(receipt);
    }


} // Namespace VideoStoreTests

