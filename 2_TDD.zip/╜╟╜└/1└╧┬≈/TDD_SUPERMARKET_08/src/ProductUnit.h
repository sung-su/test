﻿#ifndef _PRODUCTUNIT_H_
#define _PRODUCTUNIT_H_

enum class ProductUnit {
	Kilo, Each
};

#endif