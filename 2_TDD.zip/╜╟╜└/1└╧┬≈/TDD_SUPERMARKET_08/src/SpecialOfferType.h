﻿#ifndef _SPECIALOFFERTYPE_H_
#define _SPECIALOFFERTYPE_H_

enum class SpecialOfferType {
	ThreeForTwo, 
	TenPercentDiscount, 
	TwoForAmount, 
	FiveForAmount,
	BundlePercentDiscount
};

#endif