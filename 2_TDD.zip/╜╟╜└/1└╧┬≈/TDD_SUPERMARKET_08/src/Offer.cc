﻿#include "Offer.h"

Offer::Offer(Offer& o)
{
	offerType = o.offerType;
	product = o.product;
	argument = o.argument;
}
