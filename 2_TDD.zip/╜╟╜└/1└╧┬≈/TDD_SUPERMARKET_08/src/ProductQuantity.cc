﻿#include "ProductQuantity.h"

ProductQuantity::ProductQuantity(Product product, double weight)
{
	this->product = product;
	this->quantity = weight;
}
