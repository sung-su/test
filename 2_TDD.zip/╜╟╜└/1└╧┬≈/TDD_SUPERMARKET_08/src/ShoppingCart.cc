﻿#include "ShoppingCart.h"
#include <sstream>

void ShoppingCart::addItemQuantity(Product& product, double quantity)
{
	productQuantities[product] += quantity;
}

void ShoppingCart::handleOffers(Receipt& receipt, map<string, Offer> & offers, SupermarketCatalog& catalog)
{
	for (auto kv: productQuantities)
	{
		const Product& product = kv.first;
		double& quantity = kv.second;

		auto it = offers.find(product.getName());

		if ( it != offers.end())
		{
			auto& offer = it->second;
			double unitPrice = catalog.getUnitPrice(product);
			int quantityAsInt = (int)quantity;

			int x = 1;
			if (offer.offerType == SpecialOfferType::ThreeForTwo) {
				x = 3;
			}else if (offer.offerType == SpecialOfferType::TwoForAmount) {
				x = 2;
				if (quantityAsInt >= 2) {
					double total = offer.argument * (quantityAsInt / x) + (quantityAsInt % 2) * unitPrice;
					double discountN = unitPrice * quantity - total;

					receipt.addDiscount(Discount(product, string("2 for ") + to_string(offer.argument), discountN));
				}
			}
			else if (offer.offerType == SpecialOfferType::FiveForAmount) {
				x = 5;
			}

			int numberOfXs = quantityAsInt / x;

			if (offer.offerType == SpecialOfferType::ThreeForTwo && quantityAsInt > 2) {

				double discoutnAmount = quantity * unitPrice - ((numberOfXs * 2 * unitPrice) + quantityAsInt % 3 * unitPrice);

				receipt.addDiscount(Discount(product, string("3 for 2 "), discoutnAmount));
			}
			else if (offer.offerType == SpecialOfferType::TenPercentDiscount) {
				char buf[20];
				snprintf(buf, 20, "%.1f%% off", offer.argument);
				receipt.addDiscount(Discount(product, string(buf), 
									quantity * unitPrice * offer.argument / 100.0));
				
			}
			else if (offer.offerType == SpecialOfferType::FiveForAmount && quantityAsInt >= 5) {

				double discountTotal = unitPrice * quantity - (offer.argument * numberOfXs + quantityAsInt % 5 * unitPrice);

				receipt.addDiscount(Discount(product, to_string(x) + string(" for ") + to_string(offer.argument), discountTotal));
			}
		}
	}
}
