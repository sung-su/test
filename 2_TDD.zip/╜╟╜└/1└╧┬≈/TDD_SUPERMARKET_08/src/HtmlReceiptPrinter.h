﻿
#ifndef _HTMLRECEIPTPRINTER_H_
#define _HTMLRECEIPTPRINTER_H_
#include <string>
#include "Receipt.h"

class HTMLReceiptPrinter {
public:
	string printReceipt(Receipt& receitp) {
		return string("HTML Receipt");
	}
};

#endif
