﻿#include "../src/SupermarketCatalog.h"
#include "../src/Product.h"
#include "../src/Teller.h"
#include "../src/ShoppingCart.h"
#include "../src/Receipt.h"
#include <string>
#include "gtest/gtest.h"
#include "FakeCatalog.h"

using namespace std;

namespace {
    class SupermarketTest : public ::testing::Test {
        protected:
        void SetUp() override {
            toothbrush.setValue("toothbrush", ProductUnit::Each);
            apples.setValue("apples", ProductUnit::Kilo);
            rice.setValue("rice", ProductUnit::Each);
            tubesOfToothpaste.setValue("tubesOfToothpaste", ProductUnit::Each);
            cherryTomatoes.setValue("cherryTomatoes", ProductUnit::Each);
            pringles.setValue("pringles", ProductUnit::Each);
            coke.setValue("coke", ProductUnit::Each);

            catalog.addProduct(toothbrush, 0.99);
            catalog.addProduct(apples, 1.99);
            catalog.addProduct(rice, 2.49);
            catalog.addProduct(tubesOfToothpaste, 1.79);
            catalog.addProduct(cherryTomatoes, 0.69);
            catalog.addProduct(pringles, 1.2);
            catalog.addProduct(coke, 0.6);
        }

        FakeCatalog catalog;
        Product toothbrush;
        Product apples;
        Product rice;
        Product tubesOfToothpaste;
        Product cherryTomatoes;
        Product pringles;
        Product coke;
        ShoppingCart cart;
        Receipt receipt;
    };

    TEST_F(SupermarketTest, threeForTwoDiscountWithLessThanTwoTest) {
        Teller teller(catalog);
        teller.addSpecialOffer(SpecialOfferType::ThreeForTwo, toothbrush, 0.0);

        cart.addItemQuantity(toothbrush, 1.0);        
        teller.checksOutArticlesFrom(cart, receipt);
        
        ASSERT_DOUBLE_EQ(0.99, receipt.getTotalPrice());
        EXPECT_EQ(0, receipt.getDiscounts().size());
        ASSERT_EQ(1, receipt.getReceiptItems().size());

        ReceiptItem& receiptItem = receipt.getReceiptItems()[0];

        ASSERT_EQ(toothbrush, receiptItem.getProduct());
       
        ASSERT_DOUBLE_EQ(0.99, receiptItem.getPrice());
        ASSERT_DOUBLE_EQ(0.99, receiptItem.getTotalPrice());
        ASSERT_DOUBLE_EQ(1.0, receiptItem.getQuantity());
    }

    TEST_F(SupermarketTest, threeForTwoDiscountWithMoreThanTwoTest) {
        Teller teller(catalog);
        teller.addSpecialOffer(SpecialOfferType::ThreeForTwo, toothbrush, 0.0);

        cart.addItemQuantity(toothbrush, 6.0);
        teller.checksOutArticlesFrom(cart, receipt);
        
        ASSERT_DOUBLE_EQ(3.96, receipt.getTotalPrice());
        EXPECT_EQ(1, receipt.getDiscounts().size());
        ASSERT_EQ(1, receipt.getReceiptItems().size());

        ReceiptItem& receiptItem = receipt.getReceiptItems()[0];

        ASSERT_EQ(toothbrush, receiptItem.getProduct());
       
        ASSERT_DOUBLE_EQ(0.99, receiptItem.getPrice());
        ASSERT_DOUBLE_EQ(6 * 0.99, receiptItem.getTotalPrice());
        ASSERT_DOUBLE_EQ(6, receiptItem.getQuantity());
    }

    TEST_F(SupermarketTest, twentyPercentDiscountTest) {
        Teller teller(catalog);
        teller.addSpecialOffer(SpecialOfferType::TenPercentDiscount, apples, 20.0);

        cart.addItemQuantity(apples, 2.5);
        teller.checksOutArticlesFrom(cart, receipt);
        
        ASSERT_DOUBLE_EQ(3.98, receipt.getTotalPrice());
        EXPECT_EQ(1, receipt.getDiscounts().size());
        ASSERT_EQ(1, receipt.getReceiptItems().size());

        ReceiptItem& receiptItem = receipt.getReceiptItems()[0];

        ASSERT_EQ(apples, receiptItem.getProduct());
       
        ASSERT_DOUBLE_EQ(1.99, receiptItem.getPrice());
        ASSERT_DOUBLE_EQ(2.5 * 1.99, receiptItem.getTotalPrice());
        ASSERT_DOUBLE_EQ(2.5, receiptItem.getQuantity());
    }

    TEST_F(SupermarketTest, tenPercentDiscountTest) {
        Teller teller(catalog);
        teller.addSpecialOffer(SpecialOfferType::TenPercentDiscount, rice, 10.0);

        cart.addItemQuantity(rice, 3.0);
        teller.checksOutArticlesFrom(cart, receipt);
        
        ASSERT_DOUBLE_EQ(6.723, receipt.getTotalPrice());
        EXPECT_EQ(1, receipt.getDiscounts().size());
        ASSERT_EQ(1, receipt.getReceiptItems().size());

        ReceiptItem& receiptItem = receipt.getReceiptItems()[0];

        ASSERT_EQ(rice, receiptItem.getProduct());
       
        ASSERT_DOUBLE_EQ(2.49, receiptItem.getPrice());
        ASSERT_DOUBLE_EQ(3.0 * 2.49, receiptItem.getTotalPrice());
        ASSERT_DOUBLE_EQ(3.0, receiptItem.getQuantity());
    }
    
    TEST_F(SupermarketTest, twoForAmountWithLessThanTwoTest) {
        Teller teller(catalog);
        teller.addSpecialOffer(SpecialOfferType::TwoForAmount, cherryTomatoes, 0.99);

        cart.addItemQuantity(cherryTomatoes, 1.0);
        teller.checksOutArticlesFrom(cart, receipt);
        
        ASSERT_DOUBLE_EQ(0.69, receipt.getTotalPrice());
        EXPECT_EQ(0, receipt.getDiscounts().size());
        ASSERT_EQ(1, receipt.getReceiptItems().size());

        ReceiptItem& receiptItem = receipt.getReceiptItems()[0];

        ASSERT_EQ(cherryTomatoes, receiptItem.getProduct());
       
        ASSERT_DOUBLE_EQ(0.69, receiptItem.getPrice());
        ASSERT_DOUBLE_EQ(0.69, receiptItem.getTotalPrice());
        ASSERT_DOUBLE_EQ(1.0, receiptItem.getQuantity());
    }
    
    TEST_F(SupermarketTest, twoForAmountWithMoreThanTwoTest) {
        Teller teller(catalog);
        teller.addSpecialOffer(SpecialOfferType::TwoForAmount, cherryTomatoes, 0.99);

        cart.addItemQuantity(cherryTomatoes, 5.0);
        teller.checksOutArticlesFrom(cart, receipt);
        
        ASSERT_DOUBLE_EQ(2.67, receipt.getTotalPrice());
        EXPECT_EQ(1, receipt.getDiscounts().size());
        ASSERT_EQ(1, receipt.getReceiptItems().size());

        ReceiptItem& receiptItem = receipt.getReceiptItems()[0];

        ASSERT_EQ(cherryTomatoes, receiptItem.getProduct());
       
        ASSERT_DOUBLE_EQ(0.69, receiptItem.getPrice());
        ASSERT_DOUBLE_EQ(5 * 0.69, receiptItem.getTotalPrice());
        ASSERT_DOUBLE_EQ(5.0, receiptItem.getQuantity());
    }

    TEST_F(SupermarketTest, fiveForAmountWithLessThanFiveTest) {
        Teller teller(catalog);
        teller.addSpecialOffer(SpecialOfferType::FiveForAmount, tubesOfToothpaste, 7.49);
        
        cart.addItemQuantity(tubesOfToothpaste, 4.0);
        teller.checksOutArticlesFrom(cart, receipt);
        
        ASSERT_DOUBLE_EQ(4 * 1.79, receipt.getTotalPrice());
        EXPECT_EQ(0, receipt.getDiscounts().size());
        ASSERT_EQ(1, receipt.getReceiptItems().size());

        ReceiptItem& receiptItem = receipt.getReceiptItems()[0];

        ASSERT_EQ(tubesOfToothpaste, receiptItem.getProduct());
       
        ASSERT_DOUBLE_EQ(1.79, receiptItem.getPrice());
        ASSERT_DOUBLE_EQ(4 * 1.79, receiptItem.getTotalPrice());
        ASSERT_DOUBLE_EQ(4.0, receiptItem.getQuantity());
    }
    
    TEST_F(SupermarketTest, fiveForAmountWithMoreThanFiveTest) {
        Teller teller(catalog);
        teller.addSpecialOffer(SpecialOfferType::FiveForAmount, tubesOfToothpaste, 7.49);
        
        cart.addItemQuantity(tubesOfToothpaste, 6.0);
        teller.checksOutArticlesFrom(cart, receipt);
        
        ASSERT_DOUBLE_EQ(9.28, receipt.getTotalPrice());
        EXPECT_EQ(1, receipt.getDiscounts().size());
        ASSERT_EQ(1, receipt.getReceiptItems().size());

        ReceiptItem& receiptItem = receipt.getReceiptItems()[0];

        ASSERT_EQ(tubesOfToothpaste, receiptItem.getProduct());
       
        ASSERT_DOUBLE_EQ(1.79, receiptItem.getPrice());
        ASSERT_DOUBLE_EQ(6 * 1.79, receiptItem.getTotalPrice());
        ASSERT_DOUBLE_EQ(6.0, receiptItem.getQuantity());
    }

    TEST_F(SupermarketTest, bundlePercentDiscountTest) {
        Teller teller(catalog);
        teller.addSpecialOffer(SpecialOfferType::BundlePercentDiscount, pringles, 15.0);
        teller.addSpecialOffer(SpecialOfferType::BundlePercentDiscount, coke, 15.0);
        // Need a function to combine products into bundles. eg. addBundlesProduct(pringles, coke, discount);

        cart.addItemQuantity(pringles, 6.0);
        cart.addItemQuantity(coke, 5.0);
        teller.checksOutArticlesFrom(cart, receipt);
        
        EXPECT_DOUBLE_EQ(5 * (1.2 + 0.6) * 0.85 + 1.2 * 1, receipt.getTotalPrice()); // Failed
        EXPECT_EQ(2, receipt.getDiscounts().size()); // Failed
        ASSERT_EQ(2, receipt.getReceiptItems().size());

        ReceiptItem& receiptItem = receipt.getReceiptItems()[0];

        ASSERT_EQ(coke, receiptItem.getProduct());
       
        ASSERT_DOUBLE_EQ(0.6, receiptItem.getPrice());
        ASSERT_DOUBLE_EQ(5.0 * 0.6, receiptItem.getTotalPrice());
        ASSERT_DOUBLE_EQ(5.0, receiptItem.getQuantity());

        receiptItem = receipt.getReceiptItems()[1];

        ASSERT_EQ(pringles, receiptItem.getProduct());
       
        ASSERT_DOUBLE_EQ(1.2, receiptItem.getPrice());
        ASSERT_DOUBLE_EQ(6.0 * 1.2, receiptItem.getTotalPrice());
        ASSERT_DOUBLE_EQ(6.0, receiptItem.getQuantity());
    }
}
    
