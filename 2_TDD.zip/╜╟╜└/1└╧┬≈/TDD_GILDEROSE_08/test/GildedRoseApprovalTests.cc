// Include header files for test frameworks 
#include <gtest/gtest.h>
#include <ApprovalTests.hpp>

// Include code to be tested
#include "../src/GildedRose.h"

std::ostream& operator<<(std::ostream& os, const Item& obj)
{
    return os
        << "name: " << obj.name
        << ", sellIn: " << obj.sellIn
        << ", quality: " << obj.quality;
}

TEST(GildedRoseApprovalTests, VerifyCombinations) {

    std::vector<string> names { "+5 Dexterity Vest", "Aged Brie", "Elixir of the Mongoose", "Sulfuras, Hand of Ragnaros", "Backstage passes to a TAFKAL80ETC concert" };
    std::vector<int> sellIns { 10, 2, 5, 0, 15 };
    std::vector<int> qualities { 20, 0, 7, 80 };

    auto f = [](string name, int sellIn, int quality) {
        vector<Item> items = {Item(name, sellIn, quality)};
        GildedRose app(items);
        app.updateQuality();
        return items[0];
    };

    ApprovalTests::CombinationApprovals::verifyAllCombinations(
            f,
            names, sellIns, qualities);

}

TEST(GildedRoseApprovalTests, Verify) {
    int itemCount = 4;
    vector<Item> items;
    items.push_back(Item("+5 Dexterity Vest", 10, 20));
    items.push_back(Item("Sulfuras, Hand of Ragnaros", 0, 80));
    items.push_back(Item("Aged Brie", 2, 0));
    items.push_back(Item("Backstage passes to a TAFKAL80ETC concert", 15, 20));
    GildedRose app(items);
    app.updateQuality();

    std::string itemsString = "";
    for (int i = 0; i < itemCount; i++)
    {
        itemsString.append("[" + to_string(i) + "] ");
        itemsString.append(items[i].name);
        itemsString.append(", ");
        itemsString.append(to_string(items[i].sellIn));
        itemsString.append(", ");
        itemsString.append(to_string(items[i].quality));
        itemsString.append("\n");
    }
    
    ApprovalTests::Approvals::verify(itemsString);
}    

TEST(GildedRoseApprovalTests, VerifyAll) {
    vector<Item> items;
    items.push_back(Item("+5 Dexterity Vest", 10, 20));
    items.push_back(Item("Sulfuras, Hand of Ragnaros", 0, 80));
    items.push_back(Item("Aged Brie", 2, 0));
    items.push_back(Item("Backstage passes to a TAFKAL80ETC concert", 15, 20));
    items.push_back(Item("+5 Dexterity Vest", 10, -1));
    items.push_back(Item("Sulfuras, Hand of Ragnaros", 10, -1));
    items.push_back(Item("Aged Brie", 2, -1));
    items.push_back(Item("Backstage passes to a TAFKAL80ETC concert", 15, -1));
    items.push_back(Item("+5 Dexterity Vest", 10, 0));
    items.push_back(Item("Sulfuras, Hand of Ragnaros", 10, 0));
    items.push_back(Item("Aged Brie", 2, 0));
    items.push_back(Item("Backstage passes to a TAFKAL80ETC concert", 15, 0));
    items.push_back(Item("+5 Dexterity Vest", 10, 5));
    items.push_back(Item("Sulfuras, Hand of Ragnaros", 10, 80));
    items.push_back(Item("Aged Brie", 2, 1));
    items.push_back(Item("Backstage passes to a TAFKAL80ETC concert", 15, 20));
    items.push_back(Item("+5 Dexterity Vest", 10, 50));
    items.push_back(Item("Sulfuras, Hand of Ragnaros", 0, 80));
    items.push_back(Item("Aged Brie", 1, 50));
    items.push_back(Item("Backstage passes to a TAFKAL80ETC concert", 15, 50));
    items.push_back(Item("+5 Dexterity Vest", 0, 20));
    items.push_back(Item("Sulfuras, Hand of Ragnaros", 0, 80));
    items.push_back(Item("Aged Brie", 0, 1));
    items.push_back(Item("Backstage passes to a TAFKAL80ETC concert", 0, 20));
    items.push_back(Item("Backstage passes to a TAFKAL80ETC concert", 15, 20));
    items.push_back(Item("Backstage passes to a TAFKAL80ETC concert", 10, 20));
    items.push_back(Item("Backstage passes to a TAFKAL80ETC concert", 5, 20));
    items.push_back(Item("Backstage passes to a TAFKAL80ETC concert", 0, 20));
    items.push_back(Item("+5 Dexterity Vest", -1, 20));
    items.push_back(Item("Sulfuras, Hand of Ragnaros", -1, 80));
    items.push_back(Item("Aged Brie", -1, 0));
    items.push_back(Item("Backstage passes to a TAFKAL80ETC concert", -1, 20));
    items.push_back(Item("+5 Dexterity Vest", 0, 20));
    items.push_back(Item("Sulfuras, Hand of Ragnaros", 0, 80));
    items.push_back(Item("Aged Brie", 0, 0));
    items.push_back(Item("Backstage passes to a TAFKAL80ETC concert", 0, 20));
    items.push_back(Item("+5 Dexterity Vest", 5, 20));
    items.push_back(Item("Sulfuras, Hand of Ragnaros", 10, 80));
    items.push_back(Item("Aged Brie", 2, 0));
    items.push_back(Item("Backstage passes to a TAFKAL80ETC concert", 15, 20));

    GildedRose app(items);
    app.updateQuality();
    
    ApprovalTests::Approvals::verifyAll(items);
    
} 


