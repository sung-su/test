#pragma once
#include <exception>

class UserNotLoggedInException : public std::exception
{
	
};
