# TDD_TRIPSERVICE


큰범위에서 작은 단위로 테스트를 작성한다
 - 로그인한 사용자가 없을 때 exception
 - user에게 친구가 없을 때 빈 여행정보를 return
 - user의 친구가 로그인한 사용자가 아닐 때 빈 여행정보를 return
 - user가 로그인 한 친구가 있을 때 user의 여행정보를 return


* TripDAO와 UserSession은 Mock 객체를 만들어 대체하여 사용한다.

