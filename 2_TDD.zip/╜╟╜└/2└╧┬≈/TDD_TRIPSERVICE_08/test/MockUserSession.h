#include "gmock/gmock.h"
#include "../src/UserSession.h"

class MockUserSession : public UserSession
{
public:
	MOCK_METHOD(bool, IsUserLoggedIn, (User), (override));
	MOCK_METHOD(User*, GetLoggedUser, (), (override));
};
