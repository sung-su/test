#ifndef __RPNCALCULAOTR_H__
#define  __RPNCALCULAOTR_H__

#include <string>
#include <vector>
using namespace std;

class RPNCalculator
{

public:
	RPNCalculator();
	vector<string> split(string inputString, string delimiter);
	int calc(string input_string);

private:
	vector<string> splittedString;
	vector<string> operationString;
	int usedStringCount;
	int operationPosition;

	int getFirstOperationPosition();
	int addNumber();
	int minusNumber();
	int multiflyNumber();
	int divisionNumber();
	int sqrtNumber();
	int maxNumber();

	void popUsedString();
	void insertCalculatedResult(int result);
};

#endif

