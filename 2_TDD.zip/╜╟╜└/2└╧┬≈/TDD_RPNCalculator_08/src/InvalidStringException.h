#pragma once
#include <exception>

class InvalidStringException : public std::exception
{
	
};
