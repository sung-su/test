#include "RPNCalculator.h"
#include "DividedByZeroException.h"
#include "InvalidStringException.h"
#include <cstring>
#include <cmath>
#include <iostream>
using namespace std;

RPNCalculator::RPNCalculator()
{
	operationString.push_back("+");
	operationString.push_back("-");
	operationString.push_back("*");
	operationString.push_back("/");
	operationString.push_back("SQRT");
	operationString.push_back("MAX");
}

int RPNCalculator::calc(string inputString) 
{
	if(inputString.empty())
	{
		throw InvalidStringException();
	}

	string delimiter = " ";
	splittedString = split(inputString, delimiter);
	int result = 0;
	usedStringCount = 0;
	operationPosition = 0;

	while (splittedString.size() > 0)
	{
		result = 0;
		usedStringCount = 0;
		operationPosition = getFirstOperationPosition();

		if (splittedString[operationPosition] == "+")
		{
			result = addNumber();
		}
		else if (splittedString[operationPosition] == "-")
		{
			result = minusNumber();
		}
		else if (splittedString[operationPosition] == "*")
		{
			result = multiflyNumber();
		}
		else if (splittedString[operationPosition] == "/")
		{
			result = divisionNumber();
		}
		else if (splittedString[operationPosition] == "SQRT")
		{
			result = sqrtNumber();
		}
		else if (splittedString[operationPosition] == "MAX")
		{
			result = maxNumber();
		}
		else
		{
			throw InvalidStringException();
		}
		
		popUsedString();
		insertCalculatedResult(result);
	}

	return result;
}

vector<string> RPNCalculator::split(string inputString, string delimiter)
{
	vector<string> splitted;

	if (!inputString.empty() && !delimiter.empty())
	{
		char *str = strtok((char*)inputString.c_str(), delimiter.c_str());
		while (str)
		{
			splitted.push_back(str);
			str = strtok(NULL, delimiter.c_str());
		}	
	}

	return splitted;
}

int RPNCalculator::getFirstOperationPosition()
{
	bool isMatchedOperation = false;
	for (int i = 0; i < splittedString.size(); i++)
	{
		for (int j = 0; j < operationString.size(); j++)
		{
			if (splittedString[i] == operationString[j])
			{
				isMatchedOperation = true;
				break;
			}
		}
		if (isMatchedOperation)
		{
			return i;
		}
	}
	return 0;
}

int RPNCalculator::addNumber()
{
	if (operationPosition < 2)
	{
		throw InvalidStringException();
	}

	int front = 0;
	int back = 0;
	try
	{
		front = stoi(splittedString[operationPosition - 2]);
		back = stoi(splittedString[operationPosition - 1]);
	}
	catch(const std::exception& e)
	{
		throw InvalidStringException();
	}
	
	usedStringCount = 3;
	return front + back;
}

int RPNCalculator::minusNumber()
{
	if (operationPosition < 2)
	{
		throw InvalidStringException();
	}

	int front = 0;
	int back = 0;
	try
	{
		front = stoi(splittedString[operationPosition - 2]);
		back = stoi(splittedString[operationPosition - 1]);
	}
	catch(const std::exception& e)
	{
		throw InvalidStringException();
	}
	
	usedStringCount = 3;
	return front - back;
}

int RPNCalculator::multiflyNumber()
{
	if (operationPosition < 2)
	{
		throw InvalidStringException();
	}

	int front = 0;
	int back = 0;
	try
	{
		front = stoi(splittedString[operationPosition - 2]);
		back = stoi(splittedString[operationPosition - 1]);
	}
	catch(const std::exception& e)
	{
		throw InvalidStringException();
	}
	
	usedStringCount = 3;
	return front * back;
}

int RPNCalculator::divisionNumber()
{
	if (operationPosition < 2)
	{
		throw InvalidStringException();
	}

	int front = 0;
	int back = 0;
	try
	{
		front = stoi(splittedString[operationPosition - 2]);
		back = stoi(splittedString[operationPosition - 1]);
	}
	catch(const std::exception& e)
	{
		throw InvalidStringException();
	}

	if (back == 0)
	{
		throw DiviedByZeroException();
	}

	usedStringCount = 3;
	return front / back;
}

int RPNCalculator::sqrtNumber()
{
	if (operationPosition < 1)
	{
		throw InvalidStringException();
	}

	int number = 0;
	try
	{
		number = stoi(splittedString[operationPosition - 1]);
	}
	catch(const std::exception& e)
	{
		throw InvalidStringException();
	}

	usedStringCount = 2;
	return sqrt(number);
}

int RPNCalculator::maxNumber()
{
	if (operationPosition < 2)
	{
		throw InvalidStringException();
	}

	int maxNumber = 0;
	try
	{
		usedStringCount = operationPosition + 1;
		maxNumber = stoi(splittedString[0]);
		for (int i = 1; i < usedStringCount - 1; i++)
		{
			if (stoi(splittedString[i]) > maxNumber)
			{
				maxNumber = stoi(splittedString[i]);
			}
		}
	}
	catch(const std::exception& e)
	{
		throw InvalidStringException();
	}

	return maxNumber;
}

void RPNCalculator::popUsedString()
{
	splittedString.erase(splittedString.begin() + operationPosition - usedStringCount + 1, splittedString.begin() + operationPosition + 1);
}

void RPNCalculator::insertCalculatedResult(int result)
{
	if (splittedString.size() > 0)
	{
		int beginPosition = operationPosition - usedStringCount + 1;
		splittedString.insert(splittedString.begin() + beginPosition, to_string(result));
	}
}