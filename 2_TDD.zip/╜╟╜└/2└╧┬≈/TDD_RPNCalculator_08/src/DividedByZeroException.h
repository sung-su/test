#pragma once
#include <exception>

class DiviedByZeroException : public std::exception
{
	
};
