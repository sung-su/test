#include <gtest/gtest.h>
#include "../src/RPNCalculator.h"
#include "../src/DividedByZeroException.h"
#include "../src/InvalidStringException.h"

TEST(RPNCalculatorTest, SplitNegativeStringTest) {
	RPNCalculator rpn;
	string empty;
	vector<string> splitted = rpn.split(empty, " ");
	ASSERT_EQ(0, splitted.size());
}

TEST(RPNCalculatorTest, SplitNegativeDelimiterTest) {
	RPNCalculator rpn;
	string empty;
	vector<string> splitted = rpn.split("1 2 +", empty);
	ASSERT_EQ(0, splitted.size());
}

TEST(RPNCalculatorTest, SplitNegativeTest) {
	RPNCalculator rpn;
	vector<string> str;
	str.push_back("1");
	str.push_back("2");

	vector<string> splitted = rpn.split("1 2 +", " ");
	
	ASSERT_NE(str, splitted);
}

TEST(RPNCalculatorTest, SplitPossitiveTest) {
	RPNCalculator rpn;
	vector<string> str;
	str.push_back("1");
	str.push_back("2");
	str.push_back("+");

	vector<string> splitted = rpn.split("1 2 +", " ");
	
	ASSERT_EQ(str, splitted);
}

TEST(RPNCalculatorTest, InvalidStringTest) {
	RPNCalculator rpn;
	ASSERT_THROW(rpn.calc(""), InvalidStringException);
	ASSERT_THROW(rpn.calc("9"), InvalidStringException);
	ASSERT_THROW(rpn.calc("Test"), InvalidStringException);
	ASSERT_THROW(rpn.calc("5 4 SQRT"), InvalidStringException);
	ASSERT_THROW(rpn.calc("1 +"), InvalidStringException);
	ASSERT_THROW(rpn.calc("+ 2 2"), InvalidStringException);
	ASSERT_THROW(rpn.calc("4 2 + *"), InvalidStringException);
	ASSERT_THROW(rpn.calc("5 3 9 2 4 1 MAX 1"), InvalidStringException);
}

TEST(RPNCalculatorTest, PlusTest) {
	RPNCalculator rpn;
	ASSERT_EQ(3, rpn.calc("1 2 +"));
}

TEST(RPNCalculatorTest, MinusTest) {
	RPNCalculator rpn;
	ASSERT_EQ(-1, rpn.calc("1 2 -"));
}

TEST(RPNCalculatorTest, MultiplyTest) {
	RPNCalculator rpn;
	ASSERT_EQ(6, rpn.calc("2 3 *"));
}

TEST(RPNCalculatorTest, DivisionTest) {
	RPNCalculator rpn;
	ASSERT_EQ(4, rpn.calc("20 5 /"));
}

TEST(RPNCalculatorTest, DividedByZeroTest) {
	RPNCalculator rpn;
	ASSERT_THROW(rpn.calc("20 0 /"), DiviedByZeroException);
}

TEST(RPNCalculatorTest, OneBracketTest) {
	RPNCalculator rpn;
	ASSERT_EQ(18, rpn.calc("4 2 + 3 *"));
}

TEST(RPNCalculatorTest, TwoBracketTest) {
	RPNCalculator rpn;
	ASSERT_EQ(141, rpn.calc("3 5 8 * 7 + *"));
}

TEST(RPNCalculatorTest, UseSqrtTest) {
	RPNCalculator rpn;
	ASSERT_EQ(3, rpn.calc("9 SQRT"));
}

TEST(RPNCalculatorTest, UseTwoMaxTest) {
	RPNCalculator rpn;
	ASSERT_EQ(5, rpn.calc("4 5 MAX 1 2 MAX"));
}

TEST(RPNCalculatorTest, UseMaxWithMultipleNumbersTest) {
	RPNCalculator rpn;
	ASSERT_EQ(9, rpn.calc("5 3 9 2 4 1 MAX"));
}
