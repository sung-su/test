#ifndef TVCONTROLLER_H_
#define TVCONTROLLER_H_

#include "RemoteKey.h"
#include "Tuner.h"
#include <vector>
using namespace std;

class TVController
{
public:
	TVController(Tuner* tuner);
	string previousChannel;
	string currentChannel;
	vector<string> favoriteChannels;
	vector<string> searchedChannels;

	void pushButton(remoteKey key);
	void setTunerCh(string channel);
	void addFavoriteCh();
	void setNextFavoriteCh();
	
	void upChannel();
	void upChannelWithSearchedChannels();
	void downChannel();
	void downChannelWithSearchedChannels();
	void searchChannel();

	int getMatchedIndex(vector<string> vec, int num);
private:
	Tuner* tuner_;
	std::string processingCH_;
	void setTunerCh();
	int getGreaterIndex(vector<string> vec, int num);
	int getLessIndex(vector<string> vec, int num);
};

#endif
