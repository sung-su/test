#ifndef REMOTEKEY_H_
#define REMOTEKEY_H_

enum class remoteKey{
    KEY_0 = 0,
    KEY_1 = 1,
    KEY_2 = 2,
    KEY_3 = 3,
    KEY_4 = 4,
    KEY_5 = 5,
    KEY_6 = 6,
    KEY_7 = 7,
    KEY_8 = 8,
    KEY_9 = 9,
    KEY_OK = 101,
	KEY_PREVIOUS = 102,
    KEY_ADD_FAVORITE = 103,
    KEY_NEXT_FAVORITE = 104,
    KEY_UP = 201,
    KEY_DOWN = 202,
    KEY_SEARCH_CHANNEL = 301
};

#endif

