#include "TVController.h"
#include <iostream>
#include <sstream>
#include <string>

using namespace std;

TVController::TVController(Tuner* tuner)
{
	tuner_ = tuner;
	processingCH_ = "";
    previousChannel = "0";
    currentChannel = "0";
}

void TVController::pushButton(remoteKey key)
{
    switch (key) {
        case remoteKey::KEY_0:
        case remoteKey::KEY_1:
        case remoteKey::KEY_2:
        case remoteKey::KEY_3:
        case remoteKey::KEY_4:
        case remoteKey::KEY_5:
        case remoteKey::KEY_6:
        case remoteKey::KEY_7:
        case remoteKey::KEY_8:
        case remoteKey::KEY_9:
            processingCH_ += to_string(static_cast<int>(key));
            break;

        case remoteKey::KEY_OK:
            setTunerCh();
            break;

        case remoteKey::KEY_PREVIOUS:
            setTunerCh(previousChannel);
            break;

        case remoteKey::KEY_ADD_FAVORITE:
            addFavoriteCh();
            break;

        case remoteKey::KEY_NEXT_FAVORITE:
            setNextFavoriteCh();
            break;

        case remoteKey::KEY_UP:
            if (searchedChannels.empty())
            {
                upChannel();
            }
            else
            {
                upChannelWithSearchedChannels();
            }
            break;

        case remoteKey::KEY_DOWN:
            if (searchedChannels.empty())
            {
                downChannel();
            }
            else
            {
                downChannelWithSearchedChannels();
            }
            break;

        case remoteKey::KEY_SEARCH_CHANNEL:
            searchChannel();
            break;
    }
}

void TVController::setTunerCh()
{
    previousChannel = to_string(tuner_->getCH());
    tuner_->setCH(processingCH_);
    currentChannel = processingCH_;
}

void TVController::setTunerCh(string channel)
{
    previousChannel = to_string(tuner_->getCH());
    tuner_->setCH(channel);
    currentChannel = channel;
}

void TVController::addFavoriteCh()
{
    int currentCh = tuner_->getCH();
    int index = getMatchedIndex(favoriteChannels, currentCh);

    if (index < 0)
    {
        favoriteChannels.push_back(to_string(currentCh)); // ToDo: Need to sort favoriteChannel list.
    }
    else
    {
        favoriteChannels.erase(favoriteChannels.begin() + index, favoriteChannels.begin() + index + 1);
    }
}

void TVController::setNextFavoriteCh()
{
    int currentCh = tuner_->getCH();
    string nextCh;
    int index = getGreaterIndex(favoriteChannels, currentCh);

    if (index < 0)
    {
        nextCh = favoriteChannels[0];
    }
    else
    {
        nextCh = favoriteChannels[index];
    }

    setTunerCh(nextCh);
}

void TVController::upChannel()
{
    int currentCh = tuner_->getCH();
    string nextCh;

    currentCh++;
    if (currentCh > 99)
    {
        nextCh = "0";
    }
    else
    {
        nextCh = to_string(currentCh);
    }

    setTunerCh(nextCh);
}

void TVController::upChannelWithSearchedChannels()
{
    int currentCh = tuner_->getCH();
    string nextCh;
    int index = getGreaterIndex(searchedChannels, currentCh);

    if (index < 0)
    {
        nextCh = searchedChannels[0];
    }
    else
    {
        nextCh = searchedChannels[index];
    }

    setTunerCh(nextCh);
}

void TVController::downChannel()
{
    int currentCh = tuner_->getCH();
    string nextCh;

    currentCh--;
    if (currentCh < 0)
    {
        nextCh = "99";
    }
    else
    {
        nextCh = to_string(currentCh);
    }

    setTunerCh(nextCh);
}

void TVController::downChannelWithSearchedChannels()
{
    int currentCh = tuner_->getCH();
    string nextCh;
    int index = getLessIndex(searchedChannels, currentCh);

    if (index < 0)
    {
        nextCh = searchedChannels[searchedChannels.size() - 1];
    }
    else
    {
        nextCh = searchedChannels[index];
    }

    setTunerCh(nextCh);
}

int TVController::getMatchedIndex(vector<string> vec, int num)
{
    for (int i = 0; i < vec.size(); i++)
    {
        if (stoi(vec[i]) == num)
        {
            return i;
        }
    }

    return -1;
}

int TVController::getGreaterIndex(vector<string> vec, int num)
{
    for (int i = 0; i < vec.size(); i++)
    {
        if (stoi(vec[i]) > num)
        {
            return i;
        }
    }
    return -1;
}

int TVController::getLessIndex(vector<string> vec, int num)
{
    for (int i = vec.size() - 1; i >= 0; i--)
    {
        if (stoi(vec[i]) < num)
        {
            return i;
        }
    }
    return -1;
}

void TVController::searchChannel()
{
    string seekedCh;
    while(true)
    {
        seekedCh = tuner_->seekCH();
        if (seekedCh.empty())
        {
            break;
        }

        searchedChannels.push_back(seekedCh);
    }
}