#pragma once
#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "../src/Tuner.h"

using namespace std;

class MockTuner : public Tuner
{
public:
	MOCK_METHOD(int, getCH, ());
	MOCK_METHOD(void, setCH, (string));
	MOCK_METHOD(string, seekCH, ());
};
