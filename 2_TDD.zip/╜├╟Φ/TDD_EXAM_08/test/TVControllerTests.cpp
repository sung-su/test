// TVControllerTests.cpp : Defines the entry point for the console application.
//

#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "MockTuner.h"
#include "../src/TVController.h"

using namespace testing;

// 한자리 숫자 누르고 OK 누를때
TEST(TVControllerTests, press1digitAndPressOK)
{
	MockTuner tuner;
    TVController tv(&tuner);
    
    EXPECT_CALL(tuner, setCH("1")) 
        .Times(1);

    EXPECT_CALL(tuner, getCH())
        .WillOnce(Return(0));

    tv.pushButton(remoteKey::KEY_1);
    tv.pushButton(remoteKey::KEY_OK);

    ASSERT_EQ("1", tv.currentChannel);
}

// 두자리 숫자 누를때
TEST(TVControllerTests, press2digits)
{
	MockTuner tuner;
    TVController tv(&tuner);
    
    EXPECT_CALL(tuner, setCH("12")) 
        .Times(1);

    EXPECT_CALL(tuner, getCH())
        .WillOnce(Return(0));

    tv.pushButton(remoteKey::KEY_1);
    tv.pushButton(remoteKey::KEY_2);
    tv.pushButton(remoteKey::KEY_OK);

    ASSERT_EQ("12", tv.currentChannel);
}

// 이전채널 누를때
TEST(TVControllerTests, pressPrevButton)
{
    MockTuner tuner;
    TVController tv(&tuner);

    EXPECT_CALL(tuner, setCH(_)) 
        .Times(3);

    EXPECT_CALL(tuner, getCH())
        .Times(3)
        .WillOnce(Return(0))
        .WillOnce(Return(64))
        .WillOnce(Return(12));

    tv.setTunerCh("64");
    tv.setTunerCh("12");

    tv.pushButton(remoteKey::KEY_PREVIOUS);

    ASSERT_EQ("64", tv.currentChannel);
    ASSERT_EQ("12", tv.previousChannel);    
}

// 선호채널 누를때 - 추가, 삭제
TEST(TVControllerTests, pressFavoriteButton)
{
    MockTuner tuner;
    TVController tv(&tuner);

    EXPECT_CALL(tuner, getCH())
        .WillOnce(Return(3));

    tv.favoriteChannels.push_back("1");
    tv.favoriteChannels.push_back("4");
    tv.favoriteChannels.push_back("12");
    tv.favoriteChannels.push_back("56");

    tv.pushButton(remoteKey::KEY_ADD_FAVORITE);

    ASSERT_GE(tv.getMatchedIndex(tv.favoriteChannels, 3), 0);
    ASSERT_LT(tv.getMatchedIndex(tv.favoriteChannels, 5), 0);
}

// 다음 선호 채널 누를때
TEST(TVControllerTests, pressNextFavoriteButton)
{
    MockTuner tuner;
    TVController tv(&tuner);

    EXPECT_CALL(tuner, setCH("12")) 
        .Times(1);

    EXPECT_CALL(tuner, getCH())
        .Times(2)
        .WillRepeatedly(Return(6));

    tv.favoriteChannels.push_back("1");
    tv.favoriteChannels.push_back("4");
    tv.favoriteChannels.push_back("12");
    tv.favoriteChannels.push_back("56");

    tv.pushButton(remoteKey::KEY_NEXT_FAVORITE);

    ASSERT_EQ("12", tv.currentChannel);
}

TEST(TVControllerTests, pressNextFavoriteButtonReturnBegin)
{
    MockTuner tuner;
    TVController tv(&tuner);

    EXPECT_CALL(tuner, setCH("1")) 
        .Times(1);

    EXPECT_CALL(tuner, getCH())
        .Times(2)
        .WillRepeatedly(Return(56));

    tv.favoriteChannels.push_back("1");
    tv.favoriteChannels.push_back("4");
    tv.favoriteChannels.push_back("12");
    tv.favoriteChannels.push_back("56");

    tv.pushButton(remoteKey::KEY_NEXT_FAVORITE);

    ASSERT_EQ("1", tv.currentChannel);
}

// UP을 누를때
TEST(TVControllerTests, pressUpButtonWithoutSearchedChannelList)
{
    MockTuner tuner;
    TVController tv(&tuner);

    EXPECT_CALL(tuner, setCH("7")) 
        .Times(1);

    EXPECT_CALL(tuner, getCH())
        .Times(2)
        .WillRepeatedly(Return(6));

    tv.pushButton(remoteKey::KEY_UP);

    ASSERT_EQ("7", tv.currentChannel);
}

TEST(TVControllerTests, pressUpButtonWithoutSearchedChannelListReturnBegin)
{
    MockTuner tuner;
    TVController tv(&tuner);

    EXPECT_CALL(tuner, setCH("0")) 
        .Times(1);

    EXPECT_CALL(tuner, getCH())
        .Times(2)
        .WillRepeatedly(Return(99));

    tv.pushButton(remoteKey::KEY_UP);

    ASSERT_EQ("0", tv.currentChannel);
}

// DOWN을 누를때
TEST(TVControllerTests, pressDownButtonWithoutSearchedChannelList)
{
    MockTuner tuner;
    TVController tv(&tuner);

    EXPECT_CALL(tuner, setCH("5")) 
        .Times(1);

    EXPECT_CALL(tuner, getCH())
        .Times(2)
        .WillRepeatedly(Return(6));

    tv.pushButton(remoteKey::KEY_DOWN);

    ASSERT_EQ("5", tv.currentChannel);
}

TEST(TVControllerTests, pressDownButtonWithoutSearchedChannelListReturnEnd)
{
    MockTuner tuner;
    TVController tv(&tuner);

    EXPECT_CALL(tuner, setCH("99")) 
        .Times(1);

    EXPECT_CALL(tuner, getCH())
        .Times(2)
        .WillRepeatedly(Return(0));

    tv.pushButton(remoteKey::KEY_DOWN);

    ASSERT_EQ("99", tv.currentChannel);
}

// 채널 검색을 누를때
TEST(TVControllerTests, pressSearchChannelButton)
{
    MockTuner tuner;
    TVController tv(&tuner);

    EXPECT_CALL(tuner, seekCH())
        .Times(4)
        .WillOnce(Return("4"))
        .WillOnce(Return("6"))
        .WillOnce(Return("14"))
        .WillRepeatedly(Return(""));

    tv.pushButton(remoteKey::KEY_SEARCH_CHANNEL);

    ASSERT_EQ(tv.searchedChannels[0], "4");
    ASSERT_EQ(tv.searchedChannels[1], "6");
    ASSERT_EQ(tv.searchedChannels[2], "14");
}

// 저장 채널 있는 경우 UP을 누를때
TEST(TVControllerTests, pressUpButtonWithSearchedChannelList)
{
    MockTuner tuner;
    TVController tv(&tuner);

    EXPECT_CALL(tuner, seekCH())
        .Times(4)
        .WillOnce(Return("4"))
        .WillOnce(Return("6"))
        .WillOnce(Return("14"))
        .WillRepeatedly(Return(""));

    EXPECT_CALL(tuner, setCH("14"))
        .Times(1);

    EXPECT_CALL(tuner, getCH())
        .Times(2)
        .WillRepeatedly(Return(6));

    tv.searchChannel();

    tv.pushButton(remoteKey::KEY_UP);

    ASSERT_EQ("14", tv.currentChannel);
}

TEST(TVControllerTests, pressUpButtonWithSearchedChannelListReturnBegin)
{
    MockTuner tuner;
    TVController tv(&tuner);

    EXPECT_CALL(tuner, seekCH())
        .Times(4)
        .WillOnce(Return("4"))
        .WillOnce(Return("6"))
        .WillOnce(Return("14"))
        .WillRepeatedly(Return(""));

    EXPECT_CALL(tuner, setCH("4"))
        .Times(1);

    EXPECT_CALL(tuner, getCH())
        .Times(2)
        .WillRepeatedly(Return(15));

    tv.searchChannel();

    tv.pushButton(remoteKey::KEY_UP);

    ASSERT_EQ("4", tv.currentChannel);
}

// 저장 채널 있는 경우 DOWN을 누를때
TEST(TVControllerTests, pressDownButtonWithSearchedChannelList)
{
    MockTuner tuner;
    TVController tv(&tuner);

    EXPECT_CALL(tuner, seekCH())
        .Times(4)
        .WillOnce(Return("4"))
        .WillOnce(Return("6"))
        .WillOnce(Return("14"))
        .WillRepeatedly(Return(""));

    EXPECT_CALL(tuner, setCH("4"))
        .Times(1);

    EXPECT_CALL(tuner, getCH())
        .Times(2)
        .WillRepeatedly(Return(6));

    tv.searchChannel();

    tv.pushButton(remoteKey::KEY_DOWN);

    ASSERT_EQ("4", tv.currentChannel);
}

TEST(TVControllerTests, pressDownButtonWithSearchedChannelListReturnEnd)
{
    MockTuner tuner;
    TVController tv(&tuner);

    EXPECT_CALL(tuner, seekCH())
        .Times(4)
        .WillOnce(Return("4"))
        .WillOnce(Return("6"))
        .WillOnce(Return("14"))
        .WillRepeatedly(Return(""));

    EXPECT_CALL(tuner, setCH("14"))
        .Times(1);

    EXPECT_CALL(tuner, getCH())
        .Times(2)
        .WillRepeatedly(Return(2));

    tv.searchChannel();

    tv.pushButton(remoteKey::KEY_DOWN);

    ASSERT_EQ("14", tv.currentChannel);
}

int main(int argc, char** argv)
{
	InitGoogleMock(&argc, argv);

	return RUN_ALL_TESTS();
}